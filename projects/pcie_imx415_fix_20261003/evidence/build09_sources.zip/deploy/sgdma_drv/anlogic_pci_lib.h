/*
 * This file is part of the anlogic PCIe driver for Linux
 *
 * Copyright (c) 2020-present,  anlogic, Inc.
 * All rights reserved.
 *
 * This source code is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * The full GNU General Public License is included in this distribution in
 * the file called "COPYING".
 */

#ifndef ANLOGIC_PCIE_LIB_H
#define ANLOGIC_PCIE_LIB_H

#include <linux/version.h>
#include <linux/types.h>
#include <linux/uaccess.h>
#include <linux/module.h>
#include <linux/dma-mapping.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/jiffies.h>
#include <linux/kernel.h>
#include <linux/pci.h>
#include <linux/workqueue.h>
#include <linux/delay.h>

#define AL_IP_VER0

#define SGDMA_BAR_NUM (6)

/* anlogic PCIe device specific book-keeping */
#define XDEV_FLAG_OFFLINE   0x1

#define MAX_USER_IRQ 16

/* maximum number of desc per transfer request */
#define SGDMA_ENGINE_XFER_MAX_DESC       0x4000
#define SGDMA_ENGINE_CREDIT_XFER_MAX_DESC    0x3FF

//#define __LIBSGDMA_DEBUG__
//#define __REG_DEBUG__

#ifdef __LIBSGDMA_DEBUG__
#define dbg_io      pr_info
#define dbg_fops    pr_info
#define dbg_perf    pr_info
#define dbg_sg      pr_info
#define dbg_tfr     pr_info
#define dbg_irq     pr_info
#define dbg_init    pr_info
#define dbg_desc    pr_info
#else
/* disable debugging */
#define dbg_io(...)
#define dbg_fops(...)
#define dbg_perf(...)
#define dbg_sg(...)
#define dbg_tfr(...)
#define dbg_irq(...)
#define dbg_init(...)
#define dbg_desc(...)
#endif

/*
 * interrupts per engine, rad2_vul.sv:237
 * .REG_IRQ_OUT (reg_irq_from_ch[(channel*2) +: 2]),
 */

// Max DMA Buffer Size
#define BUF_SIZE                  (1*1024 * 1024)

//#define SGDMA_CONFIG_BAR_NUM   0

#define SGDMA_USER_BAR_BASE_OFFSET (0x80000)

/* Switch debug printing on/off */
#define SGDMA_DEBUG 0

/* SECTION: Preprocessor macros/constants */
#define SGDMA_BAR_NUM (6)

/* maximum amount of register space to map */
#define SGDMA_BAR_SIZE (0x8000UL)

/* Use this definition to poll several times between calls to schedule */
#define NUM_POLLS_PER_SCHED 100

#define SGDMA_CHANNEL_NUM_MAX (4)
/*
 * interrupts per engine, rad2_vul.sv:237
 * .REG_IRQ_OUT (reg_irq_from_ch[(channel*2) +: 2]),
 */
#define SGDMA_ENG_IRQ_NUM (1)
#define MAX_EXTRA_ADJ   0x3F

#define SGDMA_MAX_ADJ_BLOCK_SIZE 0x40
#define SGDMA_PAGE_SIZE          0x1000

#define RX_STATUS_EOP (1)

/* Target internal components on SGDMA control BAR */
#define SGDMA_OFS_INT_CTRL   (0x2000UL)
#define SGDMA_OFS_CONFIG     (0x3000UL)

/* maximum number of desc per transfer request */
#define SGDMA_TRANSFER_MAX_DESC (2048)

/* maximum size of a single DMA transfer descriptor */
#define SGDMA_DESC_BLEN_BITS 27
#define SGDMA_DESC_BLEN_MAX  ((1UL << (SGDMA_DESC_BLEN_BITS))) /* xxx hwb */

/* bits of the SG DMA control register */
#define SGDMA_CTRL_RUN_STOP          (1UL << 0)
#define SGDMA_CTRL_IE_DESC_STOPPED       (1UL << 1)
#define SGDMA_CTRL_IE_DESC_COMPLETED     (1UL << 2)
#define SGDMA_CTRL_IE_DESC_ALIGN_MISMATCH    (1UL << 3)
#define SGDMA_CTRL_IE_MAGIC_STOPPED      (1UL << 4)
#define SGDMA_CTRL_IE_IDLE_STOPPED       (1UL << 6)
#define SGDMA_CTRL_IE_READ_ERROR         (0x1FUL << 9)
#define SGDMA_CTRL_IE_DESC_ERROR         (0x1FUL << 19)
#define SGDMA_CTRL_NON_INCR_ADDR         (1UL << 25)
#define SGDMA_CTRL_POLL_MODE_WB          (1UL << 26)
#define SGDMA_CTRL_STM_MODE_WB           (1UL << 27)

/* bits of the SG DMA status register */
#define SGDMA_STAT_BUSY          (1UL << 0)
#define SGDMA_STAT_DESC_STOPPED      (1UL << 1)
#define SGDMA_STAT_DESC_COMPLETED    (1UL << 2)
#define SGDMA_STAT_ALIGN_MISMATCH    (1UL << 3)
#define SGDMA_STAT_MAGIC_STOPPED     (1UL << 4)
#define SGDMA_STAT_INVALID_LEN       (1UL << 5)
#define SGDMA_STAT_IDLE_STOPPED      (1UL << 6)

#define SGDMA_STAT_COMMON_ERR_MASK \
    (SGDMA_STAT_ALIGN_MISMATCH | SGDMA_STAT_MAGIC_STOPPED | \
     SGDMA_STAT_INVALID_LEN)

/* desc_error, C2H & H2C */
#define SGDMA_STAT_DESC_UNSUPP_REQ   (1UL << 19)
#define SGDMA_STAT_DESC_COMPL_ABORT  (1UL << 20)
#define SGDMA_STAT_DESC_PARITY_ERR   (1UL << 21)
#define SGDMA_STAT_DESC_HEADER_EP    (1UL << 22)
#define SGDMA_STAT_DESC_UNEXP_COMPL  (1UL << 23)

#define SGDMA_STAT_DESC_ERR_MASK \
    (SGDMA_STAT_DESC_UNSUPP_REQ | SGDMA_STAT_DESC_COMPL_ABORT | \
     SGDMA_STAT_DESC_PARITY_ERR | SGDMA_STAT_DESC_HEADER_EP | \
     SGDMA_STAT_DESC_UNEXP_COMPL)

/* read error: H2C */
#define SGDMA_STAT_H2C_R_UNSUPP_REQ  (1UL << 9)
#define SGDMA_STAT_H2C_R_COMPL_ABORT (1UL << 10)
#define SGDMA_STAT_H2C_R_PARITY_ERR  (1UL << 11)
#define SGDMA_STAT_H2C_R_HEADER_EP   (1UL << 12)
#define SGDMA_STAT_H2C_R_UNEXP_COMPL (1UL << 13)

#define SGDMA_STAT_H2C_R_ERR_MASK    \
    (SGDMA_STAT_H2C_R_UNSUPP_REQ | SGDMA_STAT_H2C_R_COMPL_ABORT | \
     SGDMA_STAT_H2C_R_PARITY_ERR | SGDMA_STAT_H2C_R_HEADER_EP | \
     SGDMA_STAT_H2C_R_UNEXP_COMPL)

/* write error, H2C only */
#define SGDMA_STAT_H2C_W_DECODE_ERR  (1UL << 14)
#define SGDMA_STAT_H2C_W_SLAVE_ERR   (1UL << 15)

#define SGDMA_STAT_H2C_W_ERR_MASK    \
    (SGDMA_STAT_H2C_W_DECODE_ERR | SGDMA_STAT_H2C_W_SLAVE_ERR)

/* read error: C2H */
#define SGDMA_STAT_C2H_R_DECODE_ERR  (1UL << 9)
#define SGDMA_STAT_C2H_R_SLAVE_ERR   (1UL << 10)

#define SGDMA_STAT_C2H_R_ERR_MASK    \
    (SGDMA_STAT_C2H_R_DECODE_ERR | SGDMA_STAT_C2H_R_SLAVE_ERR)

/* all combined */
#define SGDMA_STAT_H2C_ERR_MASK  \
    (SGDMA_STAT_COMMON_ERR_MASK | SGDMA_STAT_DESC_ERR_MASK | \
     SGDMA_STAT_H2C_R_ERR_MASK | SGDMA_STAT_H2C_W_ERR_MASK)

#define SGDMA_STAT_C2H_ERR_MASK  \
    (SGDMA_STAT_COMMON_ERR_MASK | SGDMA_STAT_DESC_ERR_MASK | \
     SGDMA_STAT_C2H_R_ERR_MASK)

/* bits of the SGDMA descriptor control field */
#define SGDMA_DESC_STOPPED   (1UL << 0)
#define SGDMA_DESC_COMPLETED (1UL << 1)
#define SGDMA_DESC_EOP       (1UL << 4)

#define SGDMA_PERF_RUN   (1UL << 0)
#define SGDMA_PERF_CLEAR (1UL << 1)
#define SGDMA_PERF_AUTO  (1UL << 2)

#define MAGIC_ENGINE    0xEEEEEEEEUL
#define MAGIC_DEVICE    0xDDDDDDDDUL

/* upper 16-bits of engine identifier register */
#define SGDMA_ID_H2C 0x1fc0U
#define SGDMA_ID_C2H 0x1fc1U

/* for C2H AXI-ST mode */
#define CYCLIC_RX_PAGES_MAX 256

#define LS_BYTE_MASK 0x000000FFUL

#define BLOCK_ID_MASK 0xFFF00000
#define BLOCK_ID_HEAD 0x1FC00000

#define IRQ_BLOCK_ID 0x1fc20000UL
#define CONFIG_BLOCK_ID 0x1fc30000UL

#define WB_COUNT_MASK 0x00ffffffUL
#define WB_ERR_MASK (1UL << 31)
#define POLL_TIMEOUT_SECONDS 10

#define MAX_USER_IRQ 16

#define MAX_DESC_BUS_ADDR (0xffffffffULL)

#define DESC_MAGIC 0xAD4B0000UL

#define C2H_WB 0x52B4UL

#define MAX_NUM_ENGINES (SGDMA_CHANNEL_NUM_MAX * 2)
#define H2C_CHANNEL_OFFSET 0x1000
#define SGDMA_OFFSET_FROM_CHANNEL 0x4000
#define CHANNEL_SPACING 0x100
#define TARGET_SPACING 0x1000

#define BYPASS_MODE_SPACING 0x0100

/* obtain the 32 most significant (high) bits of a 32-bit or 64-bit address */
#define PCI_DMA_H(addr) ((addr >> 16) >> 16)
/* obtain the 32 least significant (low) bits of a 32-bit or 64-bit address */
#define PCI_DMA_L(addr) (addr & 0xffffffffUL)

/* Kernel version adaptative code */
#define al_wake_up wake_up_interruptible
/* wait_event_interruptible_timeout() could return prematurely (-ERESTARTSYS)
 * if it is interrupted by a signal */
#define al_wait_event_interruptible_timeout(wq, condition, timeout) \
({\
    int __ret = 0;  \
    unsigned long expire = timeout + jiffies; \
    do { \
        __ret = wait_event_interruptible_timeout(wq, condition, \
                            timeout); \
    } while ((__ret < 0) && (jiffies < expire)); \
       __ret; \
})
#define al_wait_event_interruptible \
            wait_event_interruptible

#ifndef for_each_sgtable_sg
#define for_each_sgtable_sg(sgt, sg, i)		\
	for_each_sg((sgt)->sgl, sg, (sgt)->orig_nents, i)
#endif

/* SECTION: Enum definitions */
enum transfer_state {
    TRANSFER_STATE_NEW = 0,
    TRANSFER_STATE_SUBMITTED,
    TRANSFER_STATE_COMPLETED,
    TRANSFER_STATE_FAILED,
    TRANSFER_STATE_ABORTED
};

enum shutdown_state {
    ENGINE_SHUTDOWN_NONE = 0,   /* No shutdown in progress */
    ENGINE_SHUTDOWN_REQUEST = 1,    /* engine requested to shutdown */
    ENGINE_SHUTDOWN_IDLE = 2    /* engine has shutdown and is idle */
};

enum dev_capabilities {
    CAP_64BIT_DMA = 2,
    CAP_64BIT_DESC = 4,
    CAP_ENGINE_WRITE = 8,
    CAP_ENGINE_READ = 16
};

/* SECTION: Structure definitions */

struct sgdma_io_cb {
    void __user *buf;
    size_t len;
    void *private;
    unsigned int pages_nr;
    struct sg_table sgt;
    struct page **pages;
    /** total data size */
    unsigned int count;
    /** MM only, DDR/BRAM memory addr */
    u64 ep_addr;
    /** write: if write to the device */
    struct sgdma_request_cb *req;
    u8 write:1;
    void (*io_done)(unsigned long cb_hndl, int err);
};

struct config_regs {
    u32 identifier;
    u32 reserved_1[4];
    u32 msi_enable;
    u32 data_width;
};

/**
 * SG DMA Controller status and control registers
 *
 * These registers make the control interface for DMA transfers.
 *
 * It sits in End Point (FPGA) memory BAR[0] for 32-bit or BAR[0:1] for 64-bit.
 * It references the first descriptor which exists in Root Complex (PC) memory.
 *
 * @note The registers must be accessed using 32-bit (PCI DWORD) read/writes,
 * and their values are in little-endian byte ordering.
 */
struct engine_regs {
    u32 identifier;
    u32 control;
    u32 control_w1s;
    u32 control_w1c;
    u32 reserved_1[12]; /* padding */

    u32 status;
    u32 status_rc;
    u32 completed_desc_count;
    u32 alignments;
    u32 reserved_2[14]; /* padding */

    u32 poll_mode_wb_lo;
    u32 poll_mode_wb_hi;
    u32 interrupt_enable_mask;
    u32 interrupt_enable_mask_w1s;
    u32 interrupt_enable_mask_w1c;
    u32 reserved_3[9];  /* padding */

    u32 perf_ctrl;
    u32 perf_cyc_lo;
    u32 perf_cyc_hi;
    u32 perf_dat_lo;
    u32 perf_dat_hi;
    u32 perf_pnd_lo;
    u32 perf_pnd_hi;
} __packed;

struct engine_sgdma_regs {
    u32 identifier;
    u32 reserved_1[31]; /* padding */

    /* bus address to first descriptor in Root Complex Memory */
    u32 first_desc_lo;
    u32 first_desc_hi;
    /* number of adjacent descriptors at first_desc */
    u32 first_desc_adjacent;
    u32 credits;
} __packed;

struct msix_vec_table_entry {
    u32 msi_vec_addr_lo;
    u32 msi_vec_addr_hi;
    u32 msi_vec_data_lo;
    u32 msi_vec_data_hi;
} __packed;

struct msix_vec_table {
    struct msix_vec_table_entry entry_list[32];
} __packed;

struct interrupt_regs {
    u32 identifier;
    u32 user_int_enable;
    u32 user_int_enable_w1s;
    u32 user_int_enable_w1c;
    u32 channel_int_enable;
    u32 channel_int_enable_w1s;
    u32 channel_int_enable_w1c;
    u32 reserved_1[9];  /* padding */

    u32 user_int_request;
    u32 channel_int_request;
    u32 user_int_pending;
    u32 channel_int_pending;
    u32 reserved_2[12]; /* padding */

    u32 user_msi_vector[8];
    u32 channel_msi_vector[8];
} __packed;

struct sgdma_common_regs {
    u32 padding[8];
    u32 credit_mode_enable;
    u32 credit_mode_enable_w1s;
    u32 credit_mode_enable_w1c;
} __packed;

/* Structure for polled mode descriptor writeback */
struct sgdma_poll_wb {
    u32 completed_desc_count;
    u32 reserved_1[7];
} __packed;

/**
 * Descriptor for a single contiguous memory block transfer.
 *
 * Multiple descriptors are linked by means of the next pointer. An additional
 * extra adjacent number gives the amount of extra contiguous descriptors.
 *
 * The descriptors are in root complex memory, and the bytes in the 32-bit
 * words must be in little-endian byte ordering.
 */
struct sgdma_desc {
    u32 control;
    u32 bytes;      /* transfer length in bytes */
    u32 src_addr_lo;    /* source address (low 32-bit) */
    u32 src_addr_hi;    /* source address (high 32-bit) */
    u32 dst_addr_lo;    /* destination address (low 32-bit) */
    u32 dst_addr_hi;    /* destination address (high 32-bit) */
    /*
     * next descriptor in the single-linked list of descriptors;
     * this is the PCIe (bus) address of the next descriptor in the
     * root complex memory
     */
    u32 next_lo;        /* next desc address (low 32-bit) */
    u32 next_hi;        /* next desc address (high 32-bit) */
} __packed;

/* 32 bytes (four 32-bit words) or 64 bytes (eight 32-bit words) */
struct sgdma_result {
    u32 status;
    u32 length;
    u32 reserved_1[6];  /* padding */
} __packed;

struct sw_desc {
    dma_addr_t addr;
    unsigned int len;
    unsigned int control;
};

/* Describes a (SG DMA) single transfer for the engine */
#define XFER_FLAG_NEED_UNMAP        0x1
#define XFER_FLAG_ST_C2H_EOP_RCVED  0x2 /* ST c2h only */
#define XFER_FLAG_IGNORE_HALFWAY_IRQ	0x4
#define XFER_FLAG_ALLOC_DESC		0x8
struct sgdma_transfer {
    struct list_head entry;     /* queue of non-completed transfers */
    struct sgdma_desc *desc_virt;    /* virt addr of the 1st descriptor */
    struct sgdma_result *res_virt; /* virt addr of result for c2h streaming */
    dma_addr_t res_bus;           /* bus addr for result descriptors */
    dma_addr_t desc_bus;        /* bus addr of the first descriptor */
    int desc_adjacent;      /* adjacent descriptors at desc_bus */
    int desc_num;           /* number of descriptors in transfer */
    int desc_index;         /* index for first descriptor in transfer */
    int desc_cmpl;          /* completed descriptors */
    int desc_cmpl_th;       /* completed descriptor threshold */
    enum dma_data_direction dir;

    wait_queue_head_t wq;       /* wait queue for transfer completion */

    enum transfer_state state;  /* state of the transfer */
    unsigned int flags;
    void *private;
    int cyclic;         /* flag if transfer is cyclic */
    int last_in_request;        /* flag if last within request */
    unsigned int len;
    struct sg_table *sgt;
    struct sgdma_io_cb *cb;
};

#define REQ_FLAG_POSSIBLE_MAX_DESC	0x1
struct sgdma_request_cb {
    struct sg_table *sgt;
    unsigned int flags;
    unsigned int total_len;
    u64 ep_addr;
    unsigned int aperture;
    unsigned int offset;

    struct scatterlist *sg;
    unsigned int sg_idx;
    unsigned int sg_offset;

    struct sgdma_transfer tfer[2]; /* Use two transfers in case single request needs to be split */
    struct sgdma_io_cb *cb;

    unsigned int sw_desc_idx;
    unsigned int sw_desc_cnt;
    struct sw_desc sdesc[];
};

#if RANDOM_TEST
struct sgdma_rtest_sw_desc {
	dma_addr_t addr;
	u64 ep_addr;
	u8 *p;
	u64 len;
	u32 control;
};
#define RTFLG_BUF_ADDR    0x01
#define RTFLG_BUF_LEN     0x02
#define RTFLG_EP_ADDR     0x04
#define RTFLG_COMPLETE_F  0x08
#define RTFLG_CANCEL      0x10
#define RTFLG_CHKDATA     0x20
#define RTFLG_LOOPBACK    0x40
#define RTFLG_HWPERF      0x80
struct sgdma_rtest {
	struct sgdma_transfer tfer;
	struct sgdma_io_cb cb;
	u64 flags;
	int channel;
	int cpu;
	u32 first_desc_lo;
	u32 first_desc_hi;
	u32 next_adj;
	struct anlogic_dma_engine *engine;
	dma_addr_t addr;
	u64 ep_addr;
	void *p;
	u64 len;
	u64 ep_len;
	u32 expect_cnt;
	u32 test_cnt;
	u32 desc_num;
	u32 compl_desc_num;
	void *private;
	struct sgdma_rtest *link;
	struct work_struct work;
	struct hrtimer timer;
	bool write;
	int start_ret;
	u64 start_time;
	u64 end_time;
	u64 tm_inited:1;
	u64 do_start:1;
	int (*start)(struct sgdma_rtest *rtest);
	int (*done)(struct sgdma_rtest *rtest);
	struct sgdma_rtest_sw_desc sdesc[];
};
#endif

struct anlogic_dma_engine {
    unsigned long magic;    /* structure ID for sanity checks */
    struct anlogic_dev *sgdev;  /* parent device */
    char name[32];       /* name of this engine */
    int version;        /* version of this engine */
    //dev_t cdevno;     /* character device major:minor */
    //struct cdev cdev; /* character device (embedded struct) */

    /* HW register address offsets */
    struct engine_regs *regs;       /* Control reg BAR offset */
    struct engine_sgdma_regs *sgdma_regs;   /* SGDAM reg BAR offset */
    u32 bypass_offset;          /* Bypass mode BAR offset */

    /* Engine state, configuration and flags */
    enum shutdown_state shutdown;   /* engine shutdown mode */
    enum dma_data_direction dir;
    int device_open;    /* stream owner (character or kernel), guarded by lock */
    int running;        /* flag if the driver started engine */
    int non_incr_addr;  /* flag if non-incremental addressing used */
    int streaming;
    int addr_align;     /* source/dest alignment in bytes */
    int len_granularity;    /* transfer length multiple */
    int addr_bits;      /* HW datapath address width */
#if 1
    int channel;        /* engine indices */
    int eop_flush;     /* st c2h only, flush up the data with eop */
#else
    u8 channel:2;       /* engine indices */
    u8 streaming:1;
    u8 device_open:1;   /* flag if engine node open, ST mode only */
    u8 running:1;       /* flag if the driver started engine */
    u8 non_incr_addr:1; /* flag if non-incremental addressing used */
    u8 eop_flush:1;     /* st c2h only, flush up the data with eop */
    u8 filler:1;
#endif
    int max_extra_adj;  /* descriptor prefetch capability */
    int desc_dequeued;  /* num descriptors of completed transfers */
    u32 desc_max;       /* max # descriptors per xfer */
    u32 status;     /* last known status of device */
    /* only used for MSIX mode to store per-engine interrupt mask value */
    u32 interrupt_enable_mask_value;

    /* Transfer list management */
    struct list_head transfer_list; /* queue of transfers */

    /* Members applicable to AXI-ST C2H (cyclic) transfers */
    struct sgdma_result *cyclic_result;
    dma_addr_t cyclic_result_bus;   /* bus addr for transfer */
    struct sgdma_request_cb *cyclic_req;
    struct sg_table cyclic_sgt;
    u8 *perf_buf_virt;
    dma_addr_t perf_buf_bus; /* bus address */

    u8 eop_found; /* used only for cyclic(rx:c2h) */
    int eop_count;
    int rx_tail;    /* follows the HW */
    int rx_head;    /* where the SW reads from */
    int rx_overrun; /* flag if overrun occured */

    /* used for tx bd ring:h2c */
    int tx_tail;    /* follows the HW */
    int tx_head;    /* where the SW reads from */
    int tx_overrun; /* flag if overrun occured */
    int tx_desc_cnt;
    int tx_ring_desc_num;

    /* for copy from cyclic buffer to user buffer */
    unsigned int user_buffer_index;

    /* Members associated with polled mode support */
    u8 *poll_mode_addr_virt;    /* virt addr for descriptor writeback */
    dma_addr_t poll_mode_bus;   /* bus addr for descriptor writeback */
    /* Protected by lock: a stopped/restarted run cannot reuse old poll work. */
    u64 poll_generation;
    bool poll_removing;
    bool dma_quiescing; /* aborted run still owns its DMA mappings */
    unsigned int poll_worker_active;
    wait_queue_head_t poll_idle_wq; /* engine lifetime, not transfer lifetime */

    /* Members associated with interrupt mode support */
    wait_queue_head_t shutdown_wq;  /* wait queue for shutdown sync */

    spinlock_t lock;        /* protects concurrent access */
    int prev_cpu;           /* remember CPU# of (last) locker */
    int msix_irq_line;      /* MSI-X vector for this engine */
    u32 irq_bitmask;        /* IRQ bit mask for this engine */
    struct work_struct work;    /* Work queue for interrupt handling */

    struct mutex desc_lock;     /* protects concurrent access */
    dma_addr_t desc_bus;
    struct sgdma_desc *desc;
    int desc_idx;           /* current descriptor index */
    int desc_used;          /* total descriptors used */

    /* for performance test support */
    struct sgdma_performance_ioctl *sgdma_perf;   /* perf test control */
    wait_queue_head_t sgdma_perf_wq; /* Perf test sync */

    struct sgdma_kthread *cmplthp;
    /* completion status thread list for the queue */
    struct list_head cmplthp_list;
    /* pending work thread list */
    /* cpu attached to intr_work */
    unsigned int intr_work_cpu;

#ifdef AL_BD_RING
    /* al dma bd ring */
    struct al_ring *rx_ring;
    struct al_ring *tx_ring;
#endif

#if RANDOM_TEST
    struct sgdma_rtest *rtest;
#endif

#if DESC_BYPASS
    int is_desc_bypass;
    void *desc_bypass_reg;
#endif

    u32 irq_cnt;
};

struct anlogic_user_irq {
    struct anlogic_dev *sgdev;       /* parent device */
    u8 user_idx;            /* 0 ~ 15 */
    u8 events_irq;          /* accumulated IRQs */
    spinlock_t events_lock;     /* lock to safely update events_irq */
    wait_queue_head_t events_wq;    /* wait queue to sync waiting threads */
    irq_handler_t handler;

    void *dev;
};

struct anlogic_dev {
    struct list_head list_head;
    struct list_head rcu_node;

    unsigned long magic;        /* structure ID for sanity checks */
    struct pci_dev *pdev;   /* pci device struct from probe() */
    int idx;        /* dev index */

    const char *mod_name;       /* name of module owning the dev */

    spinlock_t lock;        /* protects concurrent access */
    unsigned int flags;

    /* PCIe BAR management */
    void __iomem *bar[SGDMA_BAR_NUM];    /* addresses for mapped BARs */
    int user_bar_idx;   /* BAR index of user logic */
    int user_bar_base_offset;   /* BAR base offset of user logic */
    int config_bar_idx; /* BAR index of SGDMA config logic */
    int bypass_bar_idx; /* BAR index of SGDMA bypass logic */
    int regions_in_use; /* flag if dev was in use during probe() */
    int got_regions;    /* flag if probe() obtained the regions */

    int user_max;
    int c2h_channel_max;
    int h2c_channel_max;

    /* Interrupt management */
    int irq_count;      /* interrupt counter */
    int irq_line;       /* flag if irq allocated successfully */
    int msi_enabled;    /* flag if msi was enabled for the device */
    int msix_enabled;   /* flag if msi-x was enabled for the device */
#if KERNEL_VERSION(4, 12, 0) > LINUX_VERSION_CODE
    struct msix_entry entry[32];    /* msi-x vector/entry table */
#endif
    struct anlogic_user_irq user_irq[16];   /* user IRQ management */
    unsigned int mask_irq_user;

    /* SGDMA engine management */
    int engines_num;    /* Total engine count */
    u32 mask_irq_h2c;
    u32 mask_irq_c2h;
    struct anlogic_dma_engine engine_h2c[SGDMA_CHANNEL_NUM_MAX]; //engine control struct is static
    struct anlogic_dma_engine engine_c2h[SGDMA_CHANNEL_NUM_MAX]; //engine control struct is static

    /* SD_Accel specific */
//  enum dev_capabilities capabilities;
    u64 feature_id;
};

#ifdef __REG_DEBUG__
#define write_register(v, iomem, off) \
    do { \
        pr_info("[reg dbg w] %s(%d): w reg 0x%p(0x%lx), 0x%08x.\n", __func__, __LINE__, iomem, (unsigned long)(off), (u32)v); \
        iowrite32(v, iomem); \
    } while(0)

#define read_register(iomem) \
    ({ \
        u32 val; \
        val = ioread32(iomem); \
        pr_info("[reg dbg r] %s(%d): 0x%pK, R reg 0x%08x.\n", __func__, __LINE__, iomem, val); \
        val; \
    })
#else
#define write_register(v, iomem, off) iowrite32(v, iomem)

#define read_register(iomem) ioread32(iomem)
#endif

extern unsigned int h2c_timeout;
extern unsigned int c2h_timeout;
extern unsigned int desc_blen_max;

static inline int sgdma_device_flag_check(struct anlogic_dev *sgdev, unsigned int f)
{
    unsigned long flags;

    spin_lock_irqsave(&sgdev->lock, flags);
    if (sgdev->flags & f) {
        spin_unlock_irqrestore(&sgdev->lock, flags);
        return 1;
    }
    spin_unlock_irqrestore(&sgdev->lock, flags);
    return 0;
}

void enable_perf(struct anlogic_dma_engine* engine);

void get_perf_stats(struct anlogic_dma_engine* engine);

int engine_service_poll(struct anlogic_dma_engine *engine, u32 expected_desc_count);
int engine_service_poll_generation(struct anlogic_dma_engine *engine,
                                  u32 expected_desc_count, u64 generation);

int engine_status_read(struct anlogic_dma_engine *engine, bool clear, bool dump);

int engine_service_shutdown(struct anlogic_dma_engine *engine);

struct sgdma_transfer *engine_start(struct anlogic_dma_engine *engine);

int engine_start_mode_config(struct anlogic_dma_engine *engine);

struct sgdma_transfer *engine_cyclic_stop(struct anlogic_dma_engine *engine);

int sgdma_engine_stop(struct anlogic_dma_engine *engine);

int transfer_init(struct anlogic_dma_engine *engine,
            struct sgdma_request_cb *req, struct sgdma_transfer *xfer);

int transfer_queue(struct anlogic_dma_engine *engine,
            struct sgdma_transfer *transfer);

void sgdma_desc_set(struct sgdma_desc *desc, dma_addr_t rc_bus_addr,
              u64 ep_addr, int len, int dir);

void sgdma_desc_control_clear(struct sgdma_desc *first, u32 clear_mask);

int sgdma_desc_control_set(struct sgdma_desc *first, u32 control_field);

void sgdma_desc_link(struct sgdma_desc *first, struct sgdma_desc *second,
               dma_addr_t second_bus);

void sgdma_desc_adjacent(struct sgdma_desc *desc, u32 next_adjacent);

u32 sgdma_get_next_adj(unsigned int remaining, u32 next_lo);

struct sgdma_request_cb * sgdma_request_alloc(unsigned int sdesc_nr);

void sgdma_request_free(struct sgdma_request_cb *req);

struct sgdma_request_cb * sgdma_init_request(struct sg_table *sgt,
                       u64 ep_addr, u32 *controls);

ssize_t sgdma_xfer_submit(void *dev_hndl, int channel, bool write, u64 ep_addr,
			  struct sg_table *sgt, bool dma_mapped, int timeout_ms,
			  u32 *controls);

int sgdma_engine_set_eop_flush(void *dev_hndl, int channel, bool write,
			       int enable);

int sgdma_engine_claim(void *dev_hndl, int channel, bool write, int eop_flush);
void sgdma_engine_release(void *dev_hndl, int channel, bool write);

int sgdma_performance_submit(struct anlogic_dev* sgdev, struct anlogic_dma_engine* engine);

ssize_t sgdma_xfer_aperture(struct anlogic_dma_engine *engine, bool write, u64 ep_addr,
            unsigned int aperture, struct sg_table *sgt,
            bool dma_mapped, int timeout_ms);

void anlogic_device_close(struct pci_dev *pdev, void *dev_hndl);

void *anlogic_device_open(const char *mname, struct pci_dev *pdev,int *user_max,int *h2c_channel_max, int *c2h_channel_max);

/* V4L2 wrapper support - exported helpers */
void *anlogic_get_sgdev(struct pci_dev *pdev);
void __iomem *anlogic_get_user_bar(struct pci_dev *pdev);
int anlogic_user_isr_register(void *dev_hndl, unsigned int mask,
			   irq_handler_t handler, void *dev);
int anlogic_user_isr_enable(void *dev_hndl, unsigned int mask);
int anlogic_user_isr_disable(void *dev_hndl, unsigned int mask);

void anlogic_unmap_user_buf(struct sgdma_io_cb *cb, bool write);
int anlogic_map_user_buf_to_sgl(struct sgdma_io_cb *cb, bool write);
size_t sg_copy_user(struct scatterlist *sgl, unsigned int nents, void __user *buf,
		    size_t buflen, off_t skip, bool to_buffer);
int sg_copy_from_user(struct sg_table *sgt, const void __user *buf, size_t buflen);
int sg_copy_to_user(struct sg_table *sgt, void __user *buf, size_t buflen);

#if RANDOM_TEST
int engine_reset_desc(struct anlogic_dma_engine *engine);
void sgdma_rtest_free(struct sgdma_rtest *rtest);
struct sgdma_rtest *sgdma_rtest_create(struct anlogic_dev *sgdev, u32 channel, bool write,
					 u64 ep_addr, u64 ep_len, u32 desc_cnt, u64 flags,
					 u32 count, struct sgdma_rtest *source);
int sgdma_rtest_xfer_init(struct sgdma_rtest *rtest);
int sgdma_rtest_xfer_submit(struct sgdma_rtest *rtest,
							int (*cb)(struct sgdma_rtest *));
int sgdma_rtest_xfer_start(struct sgdma_rtest *rtest);
int sgdma_rtest_xfer_start_mult(struct sgdma_rtest **rtest, int count);
int sgdma_rtest_xfer_cancel(struct sgdma_rtest *rtest);
int sgdma_rtest_xfer_destroy(struct sgdma_rtest *rtest);
int ioc_sgdma_rtest(struct anlogic_dev *sgdev, unsigned long arg);
#endif

#endif /* ANLOGIC_PCIE_LIB_H */

