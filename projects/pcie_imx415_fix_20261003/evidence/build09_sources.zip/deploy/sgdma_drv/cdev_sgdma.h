/*
 * This file is part of the Anlogic DMA IP Core driver for Linux
 *
 * Copyright (c) 2016-present,  Anlogic, Inc.
 * All rights reserved.
 *
 * This source code is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * The full GNU General Public License is included in this distribution in
 * the file called "COPYING".
 */

#ifndef _SGDMA_IOCALLS_POSIX_H_
#define _SGDMA_IOCALLS_POSIX_H_

#include <linux/ioctl.h>


#define IOCTL_SGDMA_PERF_V1 (1)
#define SGDMA_ADDRMODE_MEMORY (0)
#define SGDMA_ADDRMODE_FIXED (1)

/*
 * S means "Set" through a ptr,
 * T means "Tell" directly with the argument value
 * G means "Get": reply by setting through a pointer
 * Q means "Query": response is on the return value
 * X means "eXchange": switch G and S atomically
 * H means "sHift": switch T and Q atomically
 *
 * _IO(type,nr)         no arguments
 * _IOR(type,nr,datatype)   read data from driver
 * _IOW(type,nr,datatype)   write data to driver
 * _IORW(type,nr,datatype)  read/write data
 *
 * _IOC_DIR(nr)         returns direction
 * _IOC_TYPE(nr)        returns magic
 * _IOC_NR(nr)          returns number
 * _IOC_SIZE(nr)        returns size
 */

struct sgdma_performance_ioctl {
    /* IOCTL_SGDMA_IOCTL_Vx */
    uint32_t version;
    uint32_t transfer_size;
    /* measurement */
    uint32_t stopped;
    uint32_t iterations;
    uint64_t clock_cycle_count;
    uint64_t data_cycle_count;
    uint64_t pending_count;
};

struct sgdma_aperture_ioctl {
    uint64_t ep_addr;
    unsigned int aperture;
    unsigned long buffer;
    unsigned long len;
    int error;
    unsigned long done;
};

struct sgdma_desc_info {
    uint32_t len;
    uint32_t control;
};

#define SGDMA_CUSRW_FLG_CTRL		0x1
struct sgdma_cus_rw_ioctl {
    uint64_t buffer;
    uint64_t ep_addr;
    uint64_t flags;
    uint32_t done;
    uint32_t desc_cnt;
    int write;
    int error;
    struct sgdma_desc_info desc[];
};


/* IOCTL codes */

#define IOCTL_SGDMA_PERF_START   _IOW('q', 1, struct sgdma_performance_ioctl *)
#define IOCTL_SGDMA_PERF_STOP    _IOW('q', 2, struct sgdma_performance_ioctl *)
#define IOCTL_SGDMA_PERF_GET     _IOR('q', 3, struct sgdma_performance_ioctl *)
#define IOCTL_SGDMA_ADDRMODE_SET _IOW('q', 4, int)
#define IOCTL_SGDMA_ADDRMODE_GET _IOR('q', 5, int)
#define IOCTL_SGDMA_ALIGN_GET    _IOR('q', 6, int)
#define IOCTL_SGDMA_APERTURE_R   _IOW('q', 7, struct sgdma_aperture_ioctl *)
#define IOCTL_SGDMA_APERTURE_W   _IOW('q', 8, struct sgdma_aperture_ioctl *)
#define IOCTL_SGDMA_CUS_RW       _IOW('q', 9, struct sgdma_cus_rw_ioctl *)

#endif /* _SGDMA_IOCALLS_POSIX_H_ */
