/*******************************MILIANKE*******************************
*Company : MiLianKe Electronic Technology Co., Ltd.
*WebSite:https://www.milianke.com
*TechWeb:https://www.uisrc.com
*tmall-shop:https://milianke.tmall.com
*jd-shop:https://milianke.jd.com
*taobao-shop1: https://milianke.taobao.com
*Create Date: 2024/10/23
*Module Name:
*File Name:
*Description: 
*The reference demo provided by Milianke is only used for learning. 
*We cannot ensure that the demo itself is free of bugs, so users 
*should be responsible for the technical problems and consequences
*caused by the use of their own products.
*Copyright: Copyright (c) MiLianKe
*All rights reserved.
*Revision: 1.0
*Signal description
*1) I_ input
*2) O_ output
*3) IO_ input output
*4) S_ system internal signal
*5) _n activ low
*6) _dg debug signal 
*7) _r delay or register
*8) _s state mechine
*********************************************************************/
/*********ui_lut_1_4 ********************************************
@Description :   gamma=1.4
*****************************************************************/
module ui_lut_1_4 (
    input                    I_clk  ,
    input                    I_rst_n,

    input      [7:0]               I_LUT_1_4_data  ,
    output reg [11:0]              O_LUT_1_4_data  
);

    always @(*)begin 
        case (I_LUT_1_4_data)
                0:   O_LUT_1_4_data = 12'd48 ;
                1:   O_LUT_1_4_data = 12'd106;
                2:   O_LUT_1_4_data = 12'd153;
                3:   O_LUT_1_4_data = 12'd194;
                4:   O_LUT_1_4_data = 12'd232;
                5:   O_LUT_1_4_data = 12'd268;
                6:   O_LUT_1_4_data = 12'd301;
                7:   O_LUT_1_4_data = 12'd334;
                8:   O_LUT_1_4_data = 12'd365;
                9:   O_LUT_1_4_data = 12'd395;
                10:  O_LUT_1_4_data = 12'd424;
                11:  O_LUT_1_4_data = 12'd452;
                12:  O_LUT_1_4_data = 12'd480;
                13:  O_LUT_1_4_data = 12'd507;
                14:  O_LUT_1_4_data = 12'd533;
                15:  O_LUT_1_4_data = 12'd559;
                16:  O_LUT_1_4_data = 12'd584;
                17:  O_LUT_1_4_data = 12'd609;
                18:  O_LUT_1_4_data = 12'd634;
                19:  O_LUT_1_4_data = 12'd658;
                20:  O_LUT_1_4_data = 12'd682;
                21:  O_LUT_1_4_data = 12'd705;
                22:  O_LUT_1_4_data = 12'd728;
                23:  O_LUT_1_4_data = 12'd751;
                24:  O_LUT_1_4_data = 12'd774;
                25:  O_LUT_1_4_data = 12'd796;
                26:  O_LUT_1_4_data = 12'd818;
                27:  O_LUT_1_4_data = 12'd840;
                28:  O_LUT_1_4_data = 12'd861;
                29:  O_LUT_1_4_data = 12'd883;
                30:  O_LUT_1_4_data = 12'd904;
                31:  O_LUT_1_4_data = 12'd925;
                32:  O_LUT_1_4_data = 12'd946;
                33:  O_LUT_1_4_data = 12'd966;
                34:  O_LUT_1_4_data = 12'd987;
                35:  O_LUT_1_4_data = 12'd1007;
                36:  O_LUT_1_4_data = 12'd1027;
                37:  O_LUT_1_4_data = 12'd1047;
                38:  O_LUT_1_4_data = 12'd1067;
                39:  O_LUT_1_4_data = 12'd1086;
                40:  O_LUT_1_4_data = 12'd1106;
                41:  O_LUT_1_4_data = 12'd1125;
                42:  O_LUT_1_4_data = 12'd1144;
                43:  O_LUT_1_4_data = 12'd1163;
                44:  O_LUT_1_4_data = 12'd1182;
                45:  O_LUT_1_4_data = 12'd1201;
                46:  O_LUT_1_4_data = 12'd1220;
                47:  O_LUT_1_4_data = 12'd1238;
                48:  O_LUT_1_4_data = 12'd1257;
                49:  O_LUT_1_4_data = 12'd1275;
                50:  O_LUT_1_4_data = 12'd1293;
                51:  O_LUT_1_4_data = 12'd1311;
                52:  O_LUT_1_4_data = 12'd1329;
                53:  O_LUT_1_4_data = 12'd1347;
                54:  O_LUT_1_4_data = 12'd1365;
                55:  O_LUT_1_4_data = 12'd1383;
                56:  O_LUT_1_4_data = 12'd1401;
                57:  O_LUT_1_4_data = 12'd1418;
                58:  O_LUT_1_4_data = 12'd1436;
                59:  O_LUT_1_4_data = 12'd1453;
                60:  O_LUT_1_4_data = 12'd1470;
                61:  O_LUT_1_4_data = 12'd1488;
                62:  O_LUT_1_4_data = 12'd1505;
                63:  O_LUT_1_4_data = 12'd1522;
                64:  O_LUT_1_4_data = 12'd1539;
                65:  O_LUT_1_4_data = 12'd1556;
                66:  O_LUT_1_4_data = 12'd1572;
                67:  O_LUT_1_4_data = 12'd1589;
                68:  O_LUT_1_4_data = 12'd1606;
                69:  O_LUT_1_4_data = 12'd1623;
                70:  O_LUT_1_4_data = 12'd1639;
                71:  O_LUT_1_4_data = 12'd1656;
                72:  O_LUT_1_4_data = 12'd1672;
                73:  O_LUT_1_4_data = 12'd1688;
                74:  O_LUT_1_4_data = 12'd1705;
                75:  O_LUT_1_4_data = 12'd1721;
                76:  O_LUT_1_4_data = 12'd1737;
                77:  O_LUT_1_4_data = 12'd1753;
                78:  O_LUT_1_4_data = 12'd1769;
                79:  O_LUT_1_4_data = 12'd1785;
                80:  O_LUT_1_4_data = 12'd1801;
                81:  O_LUT_1_4_data = 12'd1817;
                82:  O_LUT_1_4_data = 12'd1833;
                83:  O_LUT_1_4_data = 12'd1848;
                84:  O_LUT_1_4_data = 12'd1864;
                85:  O_LUT_1_4_data = 12'd1880;
                86:  O_LUT_1_4_data = 12'd1895;
                87:  O_LUT_1_4_data = 12'd1911;
                88:  O_LUT_1_4_data = 12'd1926;
                89:  O_LUT_1_4_data = 12'd1942;
                90:  O_LUT_1_4_data = 12'd1957;
                91:  O_LUT_1_4_data = 12'd1972;
                92:  O_LUT_1_4_data = 12'd1988;
                93:  O_LUT_1_4_data = 12'd2003;
                94:  O_LUT_1_4_data = 12'd2018;
                95:  O_LUT_1_4_data = 12'd2033;
                96:  O_LUT_1_4_data = 12'd2048;
                97:  O_LUT_1_4_data = 12'd2063;
                98:  O_LUT_1_4_data = 12'd2078;
                99:  O_LUT_1_4_data = 12'd2093;
                100: O_LUT_1_4_data = 12'd2108;
                101: O_LUT_1_4_data = 12'd2123;
                102: O_LUT_1_4_data = 12'd2138;
                103: O_LUT_1_4_data = 12'd2153;
                104: O_LUT_1_4_data = 12'd2168;
                105: O_LUT_1_4_data = 12'd2182;
                106: O_LUT_1_4_data = 12'd2197;
                107: O_LUT_1_4_data = 12'd2212;
                108: O_LUT_1_4_data = 12'd2226;
                109: O_LUT_1_4_data = 12'd2241;
                110: O_LUT_1_4_data = 12'd2255;
                111: O_LUT_1_4_data = 12'd2270;
                112: O_LUT_1_4_data = 12'd2284;
                113: O_LUT_1_4_data = 12'd2299;
                114: O_LUT_1_4_data = 12'd2313;
                115: O_LUT_1_4_data = 12'd2327;
                116: O_LUT_1_4_data = 12'd2342;
                117: O_LUT_1_4_data = 12'd2356;
                118: O_LUT_1_4_data = 12'd2370;
                119: O_LUT_1_4_data = 12'd2384;
                120: O_LUT_1_4_data = 12'd2398;
                121: O_LUT_1_4_data = 12'd2413;
                122: O_LUT_1_4_data = 12'd2427;
                123: O_LUT_1_4_data = 12'd2441;
                124: O_LUT_1_4_data = 12'd2455;
                125: O_LUT_1_4_data = 12'd2469;
                126: O_LUT_1_4_data = 12'd2483;
                127: O_LUT_1_4_data = 12'd2497;
                128: O_LUT_1_4_data = 12'd2510;
                129: O_LUT_1_4_data = 12'd2524;
                130: O_LUT_1_4_data = 12'd2538;
                131: O_LUT_1_4_data = 12'd2552;
                132: O_LUT_1_4_data = 12'd2566;
                133: O_LUT_1_4_data = 12'd2579;
                134: O_LUT_1_4_data = 12'd2593;
                135: O_LUT_1_4_data = 12'd2607;
                136: O_LUT_1_4_data = 12'd2620;
                137: O_LUT_1_4_data = 12'd2634;
                138: O_LUT_1_4_data = 12'd2648;
                139: O_LUT_1_4_data = 12'd2661;
                140: O_LUT_1_4_data = 12'd2675;
                141: O_LUT_1_4_data = 12'd2688;
                142: O_LUT_1_4_data = 12'd2702;
                143: O_LUT_1_4_data = 12'd2715;
                144: O_LUT_1_4_data = 12'd2729;
                145: O_LUT_1_4_data = 12'd2742;
                146: O_LUT_1_4_data = 12'd2755;
                147: O_LUT_1_4_data = 12'd2769;
                148: O_LUT_1_4_data = 12'd2782;
                149: O_LUT_1_4_data = 12'd2795;
                150: O_LUT_1_4_data = 12'd2809;
                151: O_LUT_1_4_data = 12'd2822;
                152: O_LUT_1_4_data = 12'd2835;
                153: O_LUT_1_4_data = 12'd2848;
                154: O_LUT_1_4_data = 12'd2861;
                155: O_LUT_1_4_data = 12'd2875;
                156: O_LUT_1_4_data = 12'd2888;
                157: O_LUT_1_4_data = 12'd2901;
                158: O_LUT_1_4_data = 12'd2914;
                159: O_LUT_1_4_data = 12'd2927;
                160: O_LUT_1_4_data = 12'd2940;
                161: O_LUT_1_4_data = 12'd2953;
                162: O_LUT_1_4_data = 12'd2966;
                163: O_LUT_1_4_data = 12'd2979;
                164: O_LUT_1_4_data = 12'd2992;
                165: O_LUT_1_4_data = 12'd3005;
                166: O_LUT_1_4_data = 12'd3017;
                167: O_LUT_1_4_data = 12'd3030;
                168: O_LUT_1_4_data = 12'd3043;
                169: O_LUT_1_4_data = 12'd3056;
                170: O_LUT_1_4_data = 12'd3069;
                171: O_LUT_1_4_data = 12'd3082;
                172: O_LUT_1_4_data = 12'd3094;
                173: O_LUT_1_4_data = 12'd3107;
                174: O_LUT_1_4_data = 12'd3120;
                175: O_LUT_1_4_data = 12'd3132;
                176: O_LUT_1_4_data = 12'd3145;
                177: O_LUT_1_4_data = 12'd3158;
                178: O_LUT_1_4_data = 12'd3170;
                179: O_LUT_1_4_data = 12'd3183;
                180: O_LUT_1_4_data = 12'd3196;
                181: O_LUT_1_4_data = 12'd3208;
                182: O_LUT_1_4_data = 12'd3221;
                183: O_LUT_1_4_data = 12'd3233;
                184: O_LUT_1_4_data = 12'd3246;
                185: O_LUT_1_4_data = 12'd3258;
                186: O_LUT_1_4_data = 12'd3271;
                187: O_LUT_1_4_data = 12'd3283;
                188: O_LUT_1_4_data = 12'd3295;
                189: O_LUT_1_4_data = 12'd3308;
                190: O_LUT_1_4_data = 12'd3320;
                191: O_LUT_1_4_data = 12'd3333;
                192: O_LUT_1_4_data = 12'd3345;
                193: O_LUT_1_4_data = 12'd3357;
                194: O_LUT_1_4_data = 12'd3370;
                195: O_LUT_1_4_data = 12'd3382;
                196: O_LUT_1_4_data = 12'd3394;
                197: O_LUT_1_4_data = 12'd3406;
                198: O_LUT_1_4_data = 12'd3419;
                199: O_LUT_1_4_data = 12'd3431;
                200: O_LUT_1_4_data = 12'd3443;
                201: O_LUT_1_4_data = 12'd3455;
                202: O_LUT_1_4_data = 12'd3467;
                203: O_LUT_1_4_data = 12'd3480;
                204: O_LUT_1_4_data = 12'd3492;
                205: O_LUT_1_4_data = 12'd3504;
                206: O_LUT_1_4_data = 12'd3516;
                207: O_LUT_1_4_data = 12'd3528;
                208: O_LUT_1_4_data = 12'd3540;
                209: O_LUT_1_4_data = 12'd3552;
                210: O_LUT_1_4_data = 12'd3564;
                211: O_LUT_1_4_data = 12'd3576;
                212: O_LUT_1_4_data = 12'd3588;
                213: O_LUT_1_4_data = 12'd3600;
                214: O_LUT_1_4_data = 12'd3612;
                215: O_LUT_1_4_data = 12'd3624;
                216: O_LUT_1_4_data = 12'd3636;
                217: O_LUT_1_4_data = 12'd3648;
                218: O_LUT_1_4_data = 12'd3660;
                219: O_LUT_1_4_data = 12'd3672;
                220: O_LUT_1_4_data = 12'd3684;
                221: O_LUT_1_4_data = 12'd3695;
                222: O_LUT_1_4_data = 12'd3707;
                223: O_LUT_1_4_data = 12'd3719;
                224: O_LUT_1_4_data = 12'd3731;
                225: O_LUT_1_4_data = 12'd3743;
                226: O_LUT_1_4_data = 12'd3754;
                227: O_LUT_1_4_data = 12'd3766;
                228: O_LUT_1_4_data = 12'd3778;
                229: O_LUT_1_4_data = 12'd3790;
                230: O_LUT_1_4_data = 12'd3801;
                231: O_LUT_1_4_data = 12'd3813;
                232: O_LUT_1_4_data = 12'd3825;
                233: O_LUT_1_4_data = 12'd3837;
                234: O_LUT_1_4_data = 12'd3848;
                235: O_LUT_1_4_data = 12'd3860;
                236: O_LUT_1_4_data = 12'd3871;
                237: O_LUT_1_4_data = 12'd3883;
                238: O_LUT_1_4_data = 12'd3895;
                239: O_LUT_1_4_data = 12'd3906;
                240: O_LUT_1_4_data = 12'd3918;
                241: O_LUT_1_4_data = 12'd3929;
                242: O_LUT_1_4_data = 12'd3941;
                243: O_LUT_1_4_data = 12'd3952;
                244: O_LUT_1_4_data = 12'd3964;
                245: O_LUT_1_4_data = 12'd3975;
                246: O_LUT_1_4_data = 12'd3987;
                247: O_LUT_1_4_data = 12'd3998;
                248: O_LUT_1_4_data = 12'd4010;
                249: O_LUT_1_4_data = 12'd4021;
                250: O_LUT_1_4_data = 12'd4033;
                251: O_LUT_1_4_data = 12'd4044;
                252: O_LUT_1_4_data = 12'd4056;
                253: O_LUT_1_4_data = 12'd4067;
                254: O_LUT_1_4_data = 12'd4078;
                255: O_LUT_1_4_data = 12'd4090;
            default: O_LUT_1_4_data = 12'd4090;
        endcase
    end
    
endmodule