/*******************************MILIANKE*******************************
*Company : MiLianKe Electronic Technology Co., Ltd.
*WebSite:https://www.milianke.com
*TechWeb:https://www.uisrc.com
*tmall-shop:https://milianke.tmall.com
*jd-shop:https://milianke.jd.com
*taobao-shop1: https://milianke.taobao.com
*Create Date: 2024/10/23
*Module Name:
*File Name:
*Description: 
*The reference demo provided by Milianke is only used for learning. 
*We cannot ensure that the demo itself is free of bugs, so users 
*should be responsible for the technical problems and consequences
*caused by the use of their own products.
*Copyright: Copyright (c) MiLianKe
*All rights reserved.
*Revision: 1.0
*Signal description
*1) I_ input
*2) O_ output
*3) IO_ input output
*4) S_ system internal signal
*5) _n activ low
*6) _dg debug signal 
*7) _r delay or register
*8) _s state mechine
*********************************************************************/
/*********ui_lut_1_2 ********************************************
@Description :   gamma=1.2
*****************************************************************/
module ui_lut_1_2 (
    input                    I_clk  ,
    input                    I_rst_n,

    input      [7:0]               I_LUT_1_2_data  ,
    output reg [11:0]              O_LUT_1_2_data  
);

    always @(*)begin 
        case (I_LUT_1_2_data)
                0:   O_LUT_1_2_data = 12'd23;
                1:   O_LUT_1_2_data = 12'd57;
                2:   O_LUT_1_2_data = 12'd87;
                3:   O_LUT_1_2_data = 12'd116;
                4:   O_LUT_1_2_data = 12'd143;
                5:   O_LUT_1_2_data = 12'd169;
                6:   O_LUT_1_2_data = 12'd194;
                7:   O_LUT_1_2_data = 12'd218;
                8:   O_LUT_1_2_data = 12'd242;
                9:   O_LUT_1_2_data = 12'd266;
                10:  O_LUT_1_2_data = 12'd289;
                11:  O_LUT_1_2_data = 12'd311;
                12:  O_LUT_1_2_data = 12'd334;
                13:  O_LUT_1_2_data = 12'd356;
                14:  O_LUT_1_2_data = 12'd377;
                15:  O_LUT_1_2_data = 12'd399;
                16:  O_LUT_1_2_data = 12'd420;
                17:  O_LUT_1_2_data = 12'd441;
                18:  O_LUT_1_2_data = 12'd462;
                19:  O_LUT_1_2_data = 12'd483;
                20:  O_LUT_1_2_data = 12'd503;
                21:  O_LUT_1_2_data = 12'd524;
                22:  O_LUT_1_2_data = 12'd544;
                23:  O_LUT_1_2_data = 12'd564;
                24:  O_LUT_1_2_data = 12'd584;
                25:  O_LUT_1_2_data = 12'd603;
                26:  O_LUT_1_2_data = 12'd623;
                27:  O_LUT_1_2_data = 12'd642;
                28:  O_LUT_1_2_data = 12'd662;
                29:  O_LUT_1_2_data = 12'd681;
                30:  O_LUT_1_2_data = 12'd700;
                31:  O_LUT_1_2_data = 12'd719;
                32:  O_LUT_1_2_data = 12'd738;
                33:  O_LUT_1_2_data = 12'd757;
                34:  O_LUT_1_2_data = 12'd776;
                35:  O_LUT_1_2_data = 12'd794;
                36:  O_LUT_1_2_data = 12'd813;
                37:  O_LUT_1_2_data = 12'd831;
                38:  O_LUT_1_2_data = 12'd850;
                39:  O_LUT_1_2_data = 12'd868;
                40:  O_LUT_1_2_data = 12'd886;
                41:  O_LUT_1_2_data = 12'd904;
                42:  O_LUT_1_2_data = 12'd922;
                43:  O_LUT_1_2_data = 12'd940;
                44:  O_LUT_1_2_data = 12'd958;
                45:  O_LUT_1_2_data = 12'd976;
                46:  O_LUT_1_2_data = 12'd994;
                47:  O_LUT_1_2_data = 12'd1011;
                48:  O_LUT_1_2_data = 12'd1029;
                49:  O_LUT_1_2_data = 12'd1047;
                50:  O_LUT_1_2_data = 12'd1064;
                51:  O_LUT_1_2_data = 12'd1082;
                52:  O_LUT_1_2_data = 12'd1099;
                53:  O_LUT_1_2_data = 12'd1117;
                54:  O_LUT_1_2_data = 12'd1134;
                55:  O_LUT_1_2_data = 12'd1151;
                56:  O_LUT_1_2_data = 12'd1168;
                57:  O_LUT_1_2_data = 12'd1185;
                58:  O_LUT_1_2_data = 12'd1202;
                59:  O_LUT_1_2_data = 12'd1220;
                60:  O_LUT_1_2_data = 12'd1237;
                61:  O_LUT_1_2_data = 12'd1253;
                62:  O_LUT_1_2_data = 12'd1270;
                63:  O_LUT_1_2_data = 12'd1287;
                64:  O_LUT_1_2_data = 12'd1304;
                65:  O_LUT_1_2_data = 12'd1321;
                66:  O_LUT_1_2_data = 12'd1338;
                67:  O_LUT_1_2_data = 12'd1354;
                68:  O_LUT_1_2_data = 12'd1371;
                69:  O_LUT_1_2_data = 12'd1387;
                70:  O_LUT_1_2_data = 12'd1404;
                71:  O_LUT_1_2_data = 12'd1421;
                72:  O_LUT_1_2_data = 12'd1437;
                73:  O_LUT_1_2_data = 12'd1453;
                74:  O_LUT_1_2_data = 12'd1470;
                75:  O_LUT_1_2_data = 12'd1486;
                76:  O_LUT_1_2_data = 12'd1503;
                77:  O_LUT_1_2_data = 12'd1519;
                78:  O_LUT_1_2_data = 12'd1535;
                79:  O_LUT_1_2_data = 12'd1551;
                80:  O_LUT_1_2_data = 12'd1567;
                81:  O_LUT_1_2_data = 12'd1584;
                82:  O_LUT_1_2_data = 12'd1600;
                83:  O_LUT_1_2_data = 12'd1616;
                84:  O_LUT_1_2_data = 12'd1632;
                85:  O_LUT_1_2_data = 12'd1648;
                86:  O_LUT_1_2_data = 12'd1664;
                87:  O_LUT_1_2_data = 12'd1680;
                88:  O_LUT_1_2_data = 12'd1696;
                89:  O_LUT_1_2_data = 12'd1712;
                90:  O_LUT_1_2_data = 12'd1727;
                91:  O_LUT_1_2_data = 12'd1743;
                92:  O_LUT_1_2_data = 12'd1759;
                93:  O_LUT_1_2_data = 12'd1775;
                94:  O_LUT_1_2_data = 12'd1791;
                95:  O_LUT_1_2_data = 12'd1806;
                96:  O_LUT_1_2_data = 12'd1822;
                97:  O_LUT_1_2_data = 12'd1838;
                98:  O_LUT_1_2_data = 12'd1853;
                99:  O_LUT_1_2_data = 12'd1869;
                100: O_LUT_1_2_data = 12'd1885;
                101: O_LUT_1_2_data = 12'd1900;
                102: O_LUT_1_2_data = 12'd1916;
                103: O_LUT_1_2_data = 12'd1931;
                104: O_LUT_1_2_data = 12'd1947;
                105: O_LUT_1_2_data = 12'd1962;
                106: O_LUT_1_2_data = 12'd1977;
                107: O_LUT_1_2_data = 12'd1993;
                108: O_LUT_1_2_data = 12'd2008;
                109: O_LUT_1_2_data = 12'd2024;
                110: O_LUT_1_2_data = 12'd2039;
                111: O_LUT_1_2_data = 12'd2054;
                112: O_LUT_1_2_data = 12'd2070;
                113: O_LUT_1_2_data = 12'd2085;
                114: O_LUT_1_2_data = 12'd2100;
                115: O_LUT_1_2_data = 12'd2115;
                116: O_LUT_1_2_data = 12'd2130;
                117: O_LUT_1_2_data = 12'd2146;
                118: O_LUT_1_2_data = 12'd2161;
                119: O_LUT_1_2_data = 12'd2176;
                120: O_LUT_1_2_data = 12'd2191;
                121: O_LUT_1_2_data = 12'd2206;
                122: O_LUT_1_2_data = 12'd2221;
                123: O_LUT_1_2_data = 12'd2236;
                124: O_LUT_1_2_data = 12'd2251;
                125: O_LUT_1_2_data = 12'd2266;
                126: O_LUT_1_2_data = 12'd2281;
                127: O_LUT_1_2_data = 12'd2296;
                128: O_LUT_1_2_data = 12'd2311;
                129: O_LUT_1_2_data = 12'd2326;
                130: O_LUT_1_2_data = 12'd2341;
                131: O_LUT_1_2_data = 12'd2356;
                132: O_LUT_1_2_data = 12'd2371;
                133: O_LUT_1_2_data = 12'd2385;
                134: O_LUT_1_2_data = 12'd2400;
                135: O_LUT_1_2_data = 12'd2415;
                136: O_LUT_1_2_data = 12'd2430;
                137: O_LUT_1_2_data = 12'd2445;
                138: O_LUT_1_2_data = 12'd2459;
                139: O_LUT_1_2_data = 12'd2474;
                140: O_LUT_1_2_data = 12'd2489;
                141: O_LUT_1_2_data = 12'd2504;
                142: O_LUT_1_2_data = 12'd2518;
                143: O_LUT_1_2_data = 12'd2533;
                144: O_LUT_1_2_data = 12'd2548;
                145: O_LUT_1_2_data = 12'd2562;
                146: O_LUT_1_2_data = 12'd2577;
                147: O_LUT_1_2_data = 12'd2591;
                148: O_LUT_1_2_data = 12'd2606;
                149: O_LUT_1_2_data = 12'd2621;
                150: O_LUT_1_2_data = 12'd2635;
                151: O_LUT_1_2_data = 12'd2650;
                152: O_LUT_1_2_data = 12'd2664;
                153: O_LUT_1_2_data = 12'd2679;
                154: O_LUT_1_2_data = 12'd2693;
                155: O_LUT_1_2_data = 12'd2708;
                156: O_LUT_1_2_data = 12'd2722;
                157: O_LUT_1_2_data = 12'd2736;
                158: O_LUT_1_2_data = 12'd2751;
                159: O_LUT_1_2_data = 12'd2765;
                160: O_LUT_1_2_data = 12'd2780;
                161: O_LUT_1_2_data = 12'd2794;
                162: O_LUT_1_2_data = 12'd2808;
                163: O_LUT_1_2_data = 12'd2823;
                164: O_LUT_1_2_data = 12'd2837;
                165: O_LUT_1_2_data = 12'd2851;
                166: O_LUT_1_2_data = 12'd2866;
                167: O_LUT_1_2_data = 12'd2880;
                168: O_LUT_1_2_data = 12'd2894;
                169: O_LUT_1_2_data = 12'd2908;
                170: O_LUT_1_2_data = 12'd2923;
                171: O_LUT_1_2_data = 12'd2937;
                172: O_LUT_1_2_data = 12'd2951;
                173: O_LUT_1_2_data = 12'd2965;
                174: O_LUT_1_2_data = 12'd2979;
                175: O_LUT_1_2_data = 12'd2994;
                176: O_LUT_1_2_data = 12'd3008;
                177: O_LUT_1_2_data = 12'd3022;
                178: O_LUT_1_2_data = 12'd3036;
                179: O_LUT_1_2_data = 12'd3050;
                180: O_LUT_1_2_data = 12'd3064;
                181: O_LUT_1_2_data = 12'd3078;
                182: O_LUT_1_2_data = 12'd3092;
                183: O_LUT_1_2_data = 12'd3106;
                184: O_LUT_1_2_data = 12'd3121;
                185: O_LUT_1_2_data = 12'd3135;
                186: O_LUT_1_2_data = 12'd3149;
                187: O_LUT_1_2_data = 12'd3163;
                188: O_LUT_1_2_data = 12'd3177;
                189: O_LUT_1_2_data = 12'd3191;
                190: O_LUT_1_2_data = 12'd3205;
                191: O_LUT_1_2_data = 12'd3218;
                192: O_LUT_1_2_data = 12'd3232;
                193: O_LUT_1_2_data = 12'd3246;
                194: O_LUT_1_2_data = 12'd3260;
                195: O_LUT_1_2_data = 12'd3274;
                196: O_LUT_1_2_data = 12'd3288;
                197: O_LUT_1_2_data = 12'd3302;
                198: O_LUT_1_2_data = 12'd3316;
                199: O_LUT_1_2_data = 12'd3330;
                200: O_LUT_1_2_data = 12'd3344;
                201: O_LUT_1_2_data = 12'd3357;
                202: O_LUT_1_2_data = 12'd3371;
                203: O_LUT_1_2_data = 12'd3385;
                204: O_LUT_1_2_data = 12'd3399;
                205: O_LUT_1_2_data = 12'd3413;
                206: O_LUT_1_2_data = 12'd3426;
                207: O_LUT_1_2_data = 12'd3440;
                208: O_LUT_1_2_data = 12'd3454;
                209: O_LUT_1_2_data = 12'd3468;
                210: O_LUT_1_2_data = 12'd3481;
                211: O_LUT_1_2_data = 12'd3495;
                212: O_LUT_1_2_data = 12'd3509;
                213: O_LUT_1_2_data = 12'd3523;
                214: O_LUT_1_2_data = 12'd3536;
                215: O_LUT_1_2_data = 12'd3550;
                216: O_LUT_1_2_data = 12'd3564;
                217: O_LUT_1_2_data = 12'd3577;
                218: O_LUT_1_2_data = 12'd3591;
                219: O_LUT_1_2_data = 12'd3605;
                220: O_LUT_1_2_data = 12'd3618;
                221: O_LUT_1_2_data = 12'd3632;
                222: O_LUT_1_2_data = 12'd3645;
                223: O_LUT_1_2_data = 12'd3659;
                224: O_LUT_1_2_data = 12'd3673;
                225: O_LUT_1_2_data = 12'd3686;
                226: O_LUT_1_2_data = 12'd3700;
                227: O_LUT_1_2_data = 12'd3713;
                228: O_LUT_1_2_data = 12'd3727;
                229: O_LUT_1_2_data = 12'd3740;
                230: O_LUT_1_2_data = 12'd3754;
                231: O_LUT_1_2_data = 12'd3767;
                232: O_LUT_1_2_data = 12'd3781;
                233: O_LUT_1_2_data = 12'd3794;
                234: O_LUT_1_2_data = 12'd3808;
                235: O_LUT_1_2_data = 12'd3821;
                236: O_LUT_1_2_data = 12'd3835;
                237: O_LUT_1_2_data = 12'd3848;
                238: O_LUT_1_2_data = 12'd3862;
                239: O_LUT_1_2_data = 12'd3875;
                240: O_LUT_1_2_data = 12'd3889;
                241: O_LUT_1_2_data = 12'd3902;
                242: O_LUT_1_2_data = 12'd3915;
                243: O_LUT_1_2_data = 12'd3929;
                244: O_LUT_1_2_data = 12'd3942;
                245: O_LUT_1_2_data = 12'd3956;
                246: O_LUT_1_2_data = 12'd3969;
                247: O_LUT_1_2_data = 12'd3982;
                248: O_LUT_1_2_data = 12'd3996;
                249: O_LUT_1_2_data = 12'd4009;
                250: O_LUT_1_2_data = 12'd4022;
                251: O_LUT_1_2_data = 12'd4036;
                252: O_LUT_1_2_data = 12'd4049;
                253: O_LUT_1_2_data = 12'd4062;
                254: O_LUT_1_2_data = 12'd4076;
                255: O_LUT_1_2_data = 12'd4089;
            default: O_LUT_1_2_data = 12'd4089;
        endcase
    end
    
endmodule