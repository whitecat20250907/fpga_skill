/*******************************MILIANKE*******************************
*Company : MiLianKe Electronic Technology Co., Ltd.
*WebSite:https://www.milianke.com
*TechWeb:https://www.uisrc.com
*tmall-shop:https://milianke.tmall.com
*jd-shop:https://milianke.jd.com
*taobao-shop1: https://milianke.taobao.com
*Create Date: 2024/10/23
*Module Name:
*File Name:
*Description: 
*The reference demo provided by Milianke is only used for learning. 
*We cannot ensure that the demo itself is free of bugs, so users 
*should be responsible for the technical problems and consequences
*caused by the use of their own products.
*Copyright: Copyright (c) MiLianKe
*All rights reserved.
*Revision: 1.0
*Signal description
*1) I_ input
*2) O_ output
*3) IO_ input output
*4) S_ system internal signal
*5) _n activ low
*6) _dg debug signal 
*7) _r delay or register
*8) _s state mechine
*********************************************************************/
/*********ui_lut_1_8 ********************************************
@Description :   gamma=1.8
*****************************************************************/
module ui_lut_1_8 (
    input                                I_clk  ,
    input                                I_rst_n,

    input      [7:0]               I_LUT_1_8_data,
    output reg [11:0]              O_LUT_1_8_data  
);
    always @(*)begin 
        case (I_LUT_1_8_data)
                0:   O_LUT_1_8_data = 12'd124;
                1:   O_LUT_1_8_data = 12'd230;
                2:   O_LUT_1_8_data = 12'd306;
                3:   O_LUT_1_8_data = 12'd370;
                4:   O_LUT_1_8_data = 12'd426;
                5:   O_LUT_1_8_data = 12'd476;
                6:   O_LUT_1_8_data = 12'd523;
                7:   O_LUT_1_8_data = 12'd567;
                8:   O_LUT_1_8_data = 12'd608;
                9:   O_LUT_1_8_data = 12'd647;
                10:  O_LUT_1_8_data = 12'd684;
                11:  O_LUT_1_8_data = 12'd720;
                12:  O_LUT_1_8_data = 12'd755;
                13:  O_LUT_1_8_data = 12'd788;
                14:  O_LUT_1_8_data = 12'd820;
                15:  O_LUT_1_8_data = 12'd851;
                16:  O_LUT_1_8_data = 12'd882;
                17:  O_LUT_1_8_data = 12'd911;
                18:  O_LUT_1_8_data = 12'd940;
                19:  O_LUT_1_8_data = 12'd968;
                20:  O_LUT_1_8_data = 12'd996;
                21:  O_LUT_1_8_data = 12'd1023;
                22:  O_LUT_1_8_data = 12'd1049;
                23:  O_LUT_1_8_data = 12'd1075;
                24:  O_LUT_1_8_data = 12'd1100;
                25:  O_LUT_1_8_data = 12'd1125;
                26:  O_LUT_1_8_data = 12'd1150;
                27:  O_LUT_1_8_data = 12'd1174;
                28:  O_LUT_1_8_data = 12'd1198;
                29:  O_LUT_1_8_data = 12'd1221;
                30:  O_LUT_1_8_data = 12'd1244;
                31:  O_LUT_1_8_data = 12'd1267;
                32:  O_LUT_1_8_data = 12'd1289;
                33:  O_LUT_1_8_data = 12'd1311;
                34:  O_LUT_1_8_data = 12'd1333;
                35:  O_LUT_1_8_data = 12'd1354;
                36:  O_LUT_1_8_data = 12'd1376;
                37:  O_LUT_1_8_data = 12'd1397;
                38:  O_LUT_1_8_data = 12'd1417;
                39:  O_LUT_1_8_data = 12'd1438;
                40:  O_LUT_1_8_data = 12'd1458;
                41:  O_LUT_1_8_data = 12'd1478;
                42:  O_LUT_1_8_data = 12'd1498;
                43:  O_LUT_1_8_data = 12'd1518;
                44:  O_LUT_1_8_data = 12'd1537;
                45:  O_LUT_1_8_data = 12'd1556;
                46:  O_LUT_1_8_data = 12'd1575;
                47:  O_LUT_1_8_data = 12'd1594;
                48:  O_LUT_1_8_data = 12'd1613;
                49:  O_LUT_1_8_data = 12'd1632;
                50:  O_LUT_1_8_data = 12'd1650;
                51:  O_LUT_1_8_data = 12'd1668;
                52:  O_LUT_1_8_data = 12'd1686;
                53:  O_LUT_1_8_data = 12'd1704;
                54:  O_LUT_1_8_data = 12'd1722;
                55:  O_LUT_1_8_data = 12'd1740;
                56:  O_LUT_1_8_data = 12'd1757;
                57:  O_LUT_1_8_data = 12'd1774;
                58:  O_LUT_1_8_data = 12'd1792;
                59:  O_LUT_1_8_data = 12'd1809;
                60:  O_LUT_1_8_data = 12'd1826;
                61:  O_LUT_1_8_data = 12'd1842;
                62:  O_LUT_1_8_data = 12'd1859;
                63:  O_LUT_1_8_data = 12'd1876;
                64:  O_LUT_1_8_data = 12'd1892;
                65:  O_LUT_1_8_data = 12'd1909;
                66:  O_LUT_1_8_data = 12'd1925;
                67:  O_LUT_1_8_data = 12'd1941;
                68:  O_LUT_1_8_data = 12'd1957;
                69:  O_LUT_1_8_data = 12'd1973;
                70:  O_LUT_1_8_data = 12'd1989;
                71:  O_LUT_1_8_data = 12'd2005;
                72:  O_LUT_1_8_data = 12'd2020;
                73:  O_LUT_1_8_data = 12'd2036;
                74:  O_LUT_1_8_data = 12'd2051;
                75:  O_LUT_1_8_data = 12'd2067;
                76:  O_LUT_1_8_data = 12'd2082;
                77:  O_LUT_1_8_data = 12'd2097;
                78:  O_LUT_1_8_data = 12'd2112;
                79:  O_LUT_1_8_data = 12'd2127;
                80:  O_LUT_1_8_data = 12'd2142;
                81:  O_LUT_1_8_data = 12'd2157;
                82:  O_LUT_1_8_data = 12'd2172;
                83:  O_LUT_1_8_data = 12'd2187;
                84:  O_LUT_1_8_data = 12'd2201;
                85:  O_LUT_1_8_data = 12'd2216;
                86:  O_LUT_1_8_data = 12'd2230;
                87:  O_LUT_1_8_data = 12'd2245;
                88:  O_LUT_1_8_data = 12'd2259;
                89:  O_LUT_1_8_data = 12'd2273;
                90:  O_LUT_1_8_data = 12'd2288;
                91:  O_LUT_1_8_data = 12'd2302;
                92:  O_LUT_1_8_data = 12'd2316;
                93:  O_LUT_1_8_data = 12'd2330;
                94:  O_LUT_1_8_data = 12'd2344;
                95:  O_LUT_1_8_data = 12'd2358;
                96:  O_LUT_1_8_data = 12'd2371;
                97:  O_LUT_1_8_data = 12'd2385;
                98:  O_LUT_1_8_data = 12'd2399;
                99:  O_LUT_1_8_data = 12'd2412;
                100: O_LUT_1_8_data = 12'd2426;
                101: O_LUT_1_8_data = 12'd2439;
                102: O_LUT_1_8_data = 12'd2453;
                103: O_LUT_1_8_data = 12'd2466;
                104: O_LUT_1_8_data = 12'd2479;
                105: O_LUT_1_8_data = 12'd2493;
                106: O_LUT_1_8_data = 12'd2506;
                107: O_LUT_1_8_data = 12'd2519;
                108: O_LUT_1_8_data = 12'd2532;
                109: O_LUT_1_8_data = 12'd2545;
                110: O_LUT_1_8_data = 12'd2558;
                111: O_LUT_1_8_data = 12'd2571;
                112: O_LUT_1_8_data = 12'd2584;
                113: O_LUT_1_8_data = 12'd2597;
                114: O_LUT_1_8_data = 12'd2610;
                115: O_LUT_1_8_data = 12'd2622;
                116: O_LUT_1_8_data = 12'd2635;
                117: O_LUT_1_8_data = 12'd2648;
                118: O_LUT_1_8_data = 12'd2660;
                119: O_LUT_1_8_data = 12'd2673;
                120: O_LUT_1_8_data = 12'd2685;
                121: O_LUT_1_8_data = 12'd2698;
                122: O_LUT_1_8_data = 12'd2710;
                123: O_LUT_1_8_data = 12'd2723;
                124: O_LUT_1_8_data = 12'd2735;
                125: O_LUT_1_8_data = 12'd2747;
                126: O_LUT_1_8_data = 12'd2760;
                127: O_LUT_1_8_data = 12'd2772;
                128: O_LUT_1_8_data = 12'd2784;
                129: O_LUT_1_8_data = 12'd2796;
                130: O_LUT_1_8_data = 12'd2808;
                131: O_LUT_1_8_data = 12'd2820;
                132: O_LUT_1_8_data = 12'd2832;
                133: O_LUT_1_8_data = 12'd2844;
                134: O_LUT_1_8_data = 12'd2856;
                135: O_LUT_1_8_data = 12'd2868;
                136: O_LUT_1_8_data = 12'd2880;
                137: O_LUT_1_8_data = 12'd2891;
                138: O_LUT_1_8_data = 12'd2903;
                139: O_LUT_1_8_data = 12'd2915;
                140: O_LUT_1_8_data = 12'd2927;
                141: O_LUT_1_8_data = 12'd2938;
                142: O_LUT_1_8_data = 12'd2950;
                143: O_LUT_1_8_data = 12'd2961;
                144: O_LUT_1_8_data = 12'd2973;
                145: O_LUT_1_8_data = 12'd2985;
                146: O_LUT_1_8_data = 12'd2996;
                147: O_LUT_1_8_data = 12'd3007;
                148: O_LUT_1_8_data = 12'd3019;
                149: O_LUT_1_8_data = 12'd3030;
                150: O_LUT_1_8_data = 12'd3042;
                151: O_LUT_1_8_data = 12'd3053;
                152: O_LUT_1_8_data = 12'd3064;
                153: O_LUT_1_8_data = 12'd3075;
                154: O_LUT_1_8_data = 12'd3087;
                155: O_LUT_1_8_data = 12'd3098;
                156: O_LUT_1_8_data = 12'd3109;
                157: O_LUT_1_8_data = 12'd3120;
                158: O_LUT_1_8_data = 12'd3131;
                159: O_LUT_1_8_data = 12'd3142;
                160: O_LUT_1_8_data = 12'd3153;
                161: O_LUT_1_8_data = 12'd3164;
                162: O_LUT_1_8_data = 12'd3175;
                163: O_LUT_1_8_data = 12'd3186;
                164: O_LUT_1_8_data = 12'd3197;
                165: O_LUT_1_8_data = 12'd3208;
                166: O_LUT_1_8_data = 12'd3219;
                167: O_LUT_1_8_data = 12'd3229;
                168: O_LUT_1_8_data = 12'd3240;
                169: O_LUT_1_8_data = 12'd3251;
                170: O_LUT_1_8_data = 12'd3262;
                171: O_LUT_1_8_data = 12'd3272;
                172: O_LUT_1_8_data = 12'd3283;
                173: O_LUT_1_8_data = 12'd3294;
                174: O_LUT_1_8_data = 12'd3304;
                175: O_LUT_1_8_data = 12'd3315;
                176: O_LUT_1_8_data = 12'd3326;
                177: O_LUT_1_8_data = 12'd3336;
                178: O_LUT_1_8_data = 12'd3347;
                179: O_LUT_1_8_data = 12'd3357;
                180: O_LUT_1_8_data = 12'd3368;
                181: O_LUT_1_8_data = 12'd3378;
                182: O_LUT_1_8_data = 12'd3388;
                183: O_LUT_1_8_data = 12'd3399;
                184: O_LUT_1_8_data = 12'd3409;
                185: O_LUT_1_8_data = 12'd3419;
                186: O_LUT_1_8_data = 12'd3430;
                187: O_LUT_1_8_data = 12'd3440;
                188: O_LUT_1_8_data = 12'd3450;
                189: O_LUT_1_8_data = 12'd3461;
                190: O_LUT_1_8_data = 12'd3471;
                191: O_LUT_1_8_data = 12'd3481;
                192: O_LUT_1_8_data = 12'd3491;
                193: O_LUT_1_8_data = 12'd3501;
                194: O_LUT_1_8_data = 12'd3511;
                195: O_LUT_1_8_data = 12'd3521;
                196: O_LUT_1_8_data = 12'd3532;
                197: O_LUT_1_8_data = 12'd3542;
                198: O_LUT_1_8_data = 12'd3552;
                199: O_LUT_1_8_data = 12'd3562;
                200: O_LUT_1_8_data = 12'd3572;
                201: O_LUT_1_8_data = 12'd3582;
                202: O_LUT_1_8_data = 12'd3592;
                203: O_LUT_1_8_data = 12'd3601;
                204: O_LUT_1_8_data = 12'd3611;
                205: O_LUT_1_8_data = 12'd3621;
                206: O_LUT_1_8_data = 12'd3631;
                207: O_LUT_1_8_data = 12'd3641;
                208: O_LUT_1_8_data = 12'd3651;
                209: O_LUT_1_8_data = 12'd3661;
                210: O_LUT_1_8_data = 12'd3670;
                211: O_LUT_1_8_data = 12'd3680;
                212: O_LUT_1_8_data = 12'd3690;
                213: O_LUT_1_8_data = 12'd3700;
                214: O_LUT_1_8_data = 12'd3709;
                215: O_LUT_1_8_data = 12'd3719;
                216: O_LUT_1_8_data = 12'd3729;
                217: O_LUT_1_8_data = 12'd3738;
                218: O_LUT_1_8_data = 12'd3748;
                219: O_LUT_1_8_data = 12'd3757;
                220: O_LUT_1_8_data = 12'd3767;
                221: O_LUT_1_8_data = 12'd3777;
                222: O_LUT_1_8_data = 12'd3786;
                223: O_LUT_1_8_data = 12'd3796;
                224: O_LUT_1_8_data = 12'd3805;
                225: O_LUT_1_8_data = 12'd3815;
                226: O_LUT_1_8_data = 12'd3824;
                227: O_LUT_1_8_data = 12'd3834;
                228: O_LUT_1_8_data = 12'd3843;
                229: O_LUT_1_8_data = 12'd3852;
                230: O_LUT_1_8_data = 12'd3862;
                231: O_LUT_1_8_data = 12'd3871;
                232: O_LUT_1_8_data = 12'd3880;
                233: O_LUT_1_8_data = 12'd3890;
                234: O_LUT_1_8_data = 12'd3899;
                235: O_LUT_1_8_data = 12'd3908;
                236: O_LUT_1_8_data = 12'd3918;
                237: O_LUT_1_8_data = 12'd3927;
                238: O_LUT_1_8_data = 12'd3936;
                239: O_LUT_1_8_data = 12'd3945;
                240: O_LUT_1_8_data = 12'd3955;
                241: O_LUT_1_8_data = 12'd3964;
                242: O_LUT_1_8_data = 12'd3973;
                243: O_LUT_1_8_data = 12'd3982;
                244: O_LUT_1_8_data = 12'd3991;
                245: O_LUT_1_8_data = 12'd4001;
                246: O_LUT_1_8_data = 12'd4010;
                247: O_LUT_1_8_data = 12'd4019;
                248: O_LUT_1_8_data = 12'd4028;
                249: O_LUT_1_8_data = 12'd4037;
                250: O_LUT_1_8_data = 12'd4046;
                251: O_LUT_1_8_data = 12'd4055;
                252: O_LUT_1_8_data = 12'd4064;
                253: O_LUT_1_8_data = 12'd4073;
                254: O_LUT_1_8_data = 12'd4082;
                255: O_LUT_1_8_data = 12'd4091;
            default: O_LUT_1_8_data = 12'd4092;
        endcase
    end
endmodule