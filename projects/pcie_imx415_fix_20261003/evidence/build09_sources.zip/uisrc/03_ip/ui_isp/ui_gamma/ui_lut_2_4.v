/*******************************MILIANKE*******************************
*Company : MiLianKe Electronic Technology Co., Ltd.
*WebSite:https://www.milianke.com
*TechWeb:https://www.uisrc.com
*tmall-shop:https://milianke.tmall.com
*jd-shop:https://milianke.jd.com
*taobao-shop1: https://milianke.taobao.com
*Create Date: 2024/10/23
*Module Name:
*File Name:
*Description: 
*The reference demo provided by Milianke is only used for learning. 
*We cannot ensure that the demo itself is free of bugs, so users 
*should be responsible for the technical problems and consequences
*caused by the use of their own products.
*Copyright: Copyright (c) MiLianKe
*All rights reserved.
*Revision: 1.0
*Signal description
*1) I_ input
*2) O_ output
*3) IO_ input output
*4) S_ system internal signal
*5) _n activ low
*6) _dg debug signal 
*7) _r delay or register
*8) _s state mechine
*********************************************************************/
/*********ui_lut_2_4 ********************************************
@Description :   GAMMA=2.4
*****************************************************************/
module ui_lut_2_4 (
    input                    I_clk  ,
    input                    I_rst_n,
    input      [7:0]         I_LUT_2_4_data  ,
    output reg [11:0]        O_LUT_2_4_data  
);
    
    always @(*)begin 
        case (I_LUT_2_4_data)
                0:   O_LUT_2_4_data = 12'd317;
                1:   O_LUT_2_4_data = 12'd497;
                2:   O_LUT_2_4_data = 12'd613;
                3:   O_LUT_2_4_data = 12'd704;
                4:   O_LUT_2_4_data = 12'd781;
                5:   O_LUT_2_4_data = 12'd848;
                6:   O_LUT_2_4_data = 12'd908;
                7:   O_LUT_2_4_data = 12'd963;
                8:   O_LUT_2_4_data = 12'd1014;
                9:   O_LUT_2_4_data = 12'd1061;
                10:  O_LUT_2_4_data = 12'd1105;
                11:  O_LUT_2_4_data = 12'd1147;
                12:  O_LUT_2_4_data = 12'd1187;
                13:  O_LUT_2_4_data = 12'd1225;
                14:  O_LUT_2_4_data = 12'd1262;
                15:  O_LUT_2_4_data = 12'd1297;
                16:  O_LUT_2_4_data = 12'd1330;
                17:  O_LUT_2_4_data = 12'd1363;
                18:  O_LUT_2_4_data = 12'd1394;
                19:  O_LUT_2_4_data = 12'd1425;
                20:  O_LUT_2_4_data = 12'd1454;
                21:  O_LUT_2_4_data = 12'd1483;
                22:  O_LUT_2_4_data = 12'd1511;
                23:  O_LUT_2_4_data = 12'd1538;
                24:  O_LUT_2_4_data = 12'd1565;
                25:  O_LUT_2_4_data = 12'd1590;
                26:  O_LUT_2_4_data = 12'd1616;
                27:  O_LUT_2_4_data = 12'd1640;
                28:  O_LUT_2_4_data = 12'd1665;
                29:  O_LUT_2_4_data = 12'd1688;
                30:  O_LUT_2_4_data = 12'd1712;
                31:  O_LUT_2_4_data = 12'd1734;
                32:  O_LUT_2_4_data = 12'd1757;
                33:  O_LUT_2_4_data = 12'd1779;
                34:  O_LUT_2_4_data = 12'd1800;
                35:  O_LUT_2_4_data = 12'd1822;
                36:  O_LUT_2_4_data = 12'd1842;
                37:  O_LUT_2_4_data = 12'd1863;
                38:  O_LUT_2_4_data = 12'd1883;
                39:  O_LUT_2_4_data = 12'd1903;
                40:  O_LUT_2_4_data = 12'd1923;
                41:  O_LUT_2_4_data = 12'd1942;
                42:  O_LUT_2_4_data = 12'd1961;
                43:  O_LUT_2_4_data = 12'd1980;
                44:  O_LUT_2_4_data = 12'd1998;
                45:  O_LUT_2_4_data = 12'd2017;
                46:  O_LUT_2_4_data = 12'd2035;
                47:  O_LUT_2_4_data = 12'd2053;
                48:  O_LUT_2_4_data = 12'd2070;
                49:  O_LUT_2_4_data = 12'd2088;
                50:  O_LUT_2_4_data = 12'd2105;
                51:  O_LUT_2_4_data = 12'd2122;
                52:  O_LUT_2_4_data = 12'd2139;
                53:  O_LUT_2_4_data = 12'd2155;
                54:  O_LUT_2_4_data = 12'd2172;
                55:  O_LUT_2_4_data = 12'd2188;
                56:  O_LUT_2_4_data = 12'd2204;
                57:  O_LUT_2_4_data = 12'd2220;
                58:  O_LUT_2_4_data = 12'd2236;
                59:  O_LUT_2_4_data = 12'd2251;
                60:  O_LUT_2_4_data = 12'd2267;
                61:  O_LUT_2_4_data = 12'd2282;
                62:  O_LUT_2_4_data = 12'd2297;
                63:  O_LUT_2_4_data = 12'd2312;
                64:  O_LUT_2_4_data = 12'd2327;
                65:  O_LUT_2_4_data = 12'd2342;
                66:  O_LUT_2_4_data = 12'd2356;
                67:  O_LUT_2_4_data = 12'd2371;
                68:  O_LUT_2_4_data = 12'd2385;
                69:  O_LUT_2_4_data = 12'd2399;
                70:  O_LUT_2_4_data = 12'd2414;
                71:  O_LUT_2_4_data = 12'd2427;
                72:  O_LUT_2_4_data = 12'd2441;
                73:  O_LUT_2_4_data = 12'd2455;
                74:  O_LUT_2_4_data = 12'd2469;
                75:  O_LUT_2_4_data = 12'd2482;
                76:  O_LUT_2_4_data = 12'd2496;
                77:  O_LUT_2_4_data = 12'd2509;
                78:  O_LUT_2_4_data = 12'd2522;
                79:  O_LUT_2_4_data = 12'd2535;
                80:  O_LUT_2_4_data = 12'd2548;
                81:  O_LUT_2_4_data = 12'd2561;
                82:  O_LUT_2_4_data = 12'd2574;
                83:  O_LUT_2_4_data = 12'd2587;
                84:  O_LUT_2_4_data = 12'd2600;
                85:  O_LUT_2_4_data = 12'd2612;
                86:  O_LUT_2_4_data = 12'd2625;
                87:  O_LUT_2_4_data = 12'd2637;
                88:  O_LUT_2_4_data = 12'd2649;
                89:  O_LUT_2_4_data = 12'd2662;
                90:  O_LUT_2_4_data = 12'd2674;
                91:  O_LUT_2_4_data = 12'd2686;
                92:  O_LUT_2_4_data = 12'd2698;
                93:  O_LUT_2_4_data = 12'd2710;
                94:  O_LUT_2_4_data = 12'd2722;
                95:  O_LUT_2_4_data = 12'd2733;
                96:  O_LUT_2_4_data = 12'd2745;
                97:  O_LUT_2_4_data = 12'd2757;
                98:  O_LUT_2_4_data = 12'd2768;
                99:  O_LUT_2_4_data = 12'd2780;
                100: O_LUT_2_4_data = 12'd2791;
                101: O_LUT_2_4_data = 12'd2803;
                102: O_LUT_2_4_data = 12'd2814;
                103: O_LUT_2_4_data = 12'd2825;
                104: O_LUT_2_4_data = 12'd2836;
                105: O_LUT_2_4_data = 12'd2847;
                106: O_LUT_2_4_data = 12'd2858;
                107: O_LUT_2_4_data = 12'd2869;
                108: O_LUT_2_4_data = 12'd2880;
                109: O_LUT_2_4_data = 12'd2891;
                110: O_LUT_2_4_data = 12'd2902;
                111: O_LUT_2_4_data = 12'd2913;
                112: O_LUT_2_4_data = 12'd2923;
                113: O_LUT_2_4_data = 12'd2934;
                114: O_LUT_2_4_data = 12'd2945;
                115: O_LUT_2_4_data = 12'd2955;
                116: O_LUT_2_4_data = 12'd2966;
                117: O_LUT_2_4_data = 12'd2976;
                118: O_LUT_2_4_data = 12'd2986;
                119: O_LUT_2_4_data = 12'd2997;
                120: O_LUT_2_4_data = 12'd3007;
                121: O_LUT_2_4_data = 12'd3017;
                122: O_LUT_2_4_data = 12'd3027;
                123: O_LUT_2_4_data = 12'd3037;
                124: O_LUT_2_4_data = 12'd3047;
                125: O_LUT_2_4_data = 12'd3057;
                126: O_LUT_2_4_data = 12'd3067;
                127: O_LUT_2_4_data = 12'd3077;
                128: O_LUT_2_4_data = 12'd3087;
                129: O_LUT_2_4_data = 12'd3097;
                130: O_LUT_2_4_data = 12'd3107;
                131: O_LUT_2_4_data = 12'd3117;
                132: O_LUT_2_4_data = 12'd3126;
                133: O_LUT_2_4_data = 12'd3136;
                134: O_LUT_2_4_data = 12'd3145;
                135: O_LUT_2_4_data = 12'd3155;
                136: O_LUT_2_4_data = 12'd3165;
                137: O_LUT_2_4_data = 12'd3174;
                138: O_LUT_2_4_data = 12'd3184;
                139: O_LUT_2_4_data = 12'd3193;
                140: O_LUT_2_4_data = 12'd3202;
                141: O_LUT_2_4_data = 12'd3212;
                142: O_LUT_2_4_data = 12'd3221;
                143: O_LUT_2_4_data = 12'd3230;
                144: O_LUT_2_4_data = 12'd3239;
                145: O_LUT_2_4_data = 12'd3249;
                146: O_LUT_2_4_data = 12'd3258;
                147: O_LUT_2_4_data = 12'd3267;
                148: O_LUT_2_4_data = 12'd3276;
                149: O_LUT_2_4_data = 12'd3285;
                150: O_LUT_2_4_data = 12'd3294;
                151: O_LUT_2_4_data = 12'd3303;
                152: O_LUT_2_4_data = 12'd3312;
                153: O_LUT_2_4_data = 12'd3321;
                154: O_LUT_2_4_data = 12'd3329;
                155: O_LUT_2_4_data = 12'd3338;
                156: O_LUT_2_4_data = 12'd3347;
                157: O_LUT_2_4_data = 12'd3356;
                158: O_LUT_2_4_data = 12'd3365;
                159: O_LUT_2_4_data = 12'd3373;
                160: O_LUT_2_4_data = 12'd3382;
                161: O_LUT_2_4_data = 12'd3391;
                162: O_LUT_2_4_data = 12'd3399;
                163: O_LUT_2_4_data = 12'd3408;
                164: O_LUT_2_4_data = 12'd3416;
                165: O_LUT_2_4_data = 12'd3425;
                166: O_LUT_2_4_data = 12'd3433;
                167: O_LUT_2_4_data = 12'd3442;
                168: O_LUT_2_4_data = 12'd3450;
                169: O_LUT_2_4_data = 12'd3458;
                170: O_LUT_2_4_data = 12'd3467;
                171: O_LUT_2_4_data = 12'd3475;
                172: O_LUT_2_4_data = 12'd3483;
                173: O_LUT_2_4_data = 12'd3492;
                174: O_LUT_2_4_data = 12'd3500;
                175: O_LUT_2_4_data = 12'd3508;
                176: O_LUT_2_4_data = 12'd3516;
                177: O_LUT_2_4_data = 12'd3524;
                178: O_LUT_2_4_data = 12'd3533;
                179: O_LUT_2_4_data = 12'd3541;
                180: O_LUT_2_4_data = 12'd3549;
                181: O_LUT_2_4_data = 12'd3557;
                182: O_LUT_2_4_data = 12'd3565;
                183: O_LUT_2_4_data = 12'd3573;
                184: O_LUT_2_4_data = 12'd3581;
                185: O_LUT_2_4_data = 12'd3589;
                186: O_LUT_2_4_data = 12'd3597;
                187: O_LUT_2_4_data = 12'd3605;
                188: O_LUT_2_4_data = 12'd3612;
                189: O_LUT_2_4_data = 12'd3620;
                190: O_LUT_2_4_data = 12'd3628;
                191: O_LUT_2_4_data = 12'd3636;
                192: O_LUT_2_4_data = 12'd3644;
                193: O_LUT_2_4_data = 12'd3651;
                194: O_LUT_2_4_data = 12'd3659;
                195: O_LUT_2_4_data = 12'd3667;
                196: O_LUT_2_4_data = 12'd3675;
                197: O_LUT_2_4_data = 12'd3682;
                198: O_LUT_2_4_data = 12'd3690;
                199: O_LUT_2_4_data = 12'd3697;
                200: O_LUT_2_4_data = 12'd3705;
                201: O_LUT_2_4_data = 12'd3713;
                202: O_LUT_2_4_data = 12'd3720;
                203: O_LUT_2_4_data = 12'd3728;
                204: O_LUT_2_4_data = 12'd3735;
                205: O_LUT_2_4_data = 12'd3743;
                206: O_LUT_2_4_data = 12'd3750;
                207: O_LUT_2_4_data = 12'd3758;
                208: O_LUT_2_4_data = 12'd3765;
                209: O_LUT_2_4_data = 12'd3772;
                210: O_LUT_2_4_data = 12'd3780;
                211: O_LUT_2_4_data = 12'd3787;
                212: O_LUT_2_4_data = 12'd3794;
                213: O_LUT_2_4_data = 12'd3802;
                214: O_LUT_2_4_data = 12'd3809;
                215: O_LUT_2_4_data = 12'd3816;
                216: O_LUT_2_4_data = 12'd3824;
                217: O_LUT_2_4_data = 12'd3831;
                218: O_LUT_2_4_data = 12'd3838;
                219: O_LUT_2_4_data = 12'd3845;
                220: O_LUT_2_4_data = 12'd3852;
                221: O_LUT_2_4_data = 12'd3859;
                222: O_LUT_2_4_data = 12'd3867;
                223: O_LUT_2_4_data = 12'd3874;
                224: O_LUT_2_4_data = 12'd3881;
                225: O_LUT_2_4_data = 12'd3888;
                226: O_LUT_2_4_data = 12'd3895;
                227: O_LUT_2_4_data = 12'd3902;
                228: O_LUT_2_4_data = 12'd3909;
                229: O_LUT_2_4_data = 12'd3916;
                230: O_LUT_2_4_data = 12'd3923;
                231: O_LUT_2_4_data = 12'd3930;
                232: O_LUT_2_4_data = 12'd3937;
                233: O_LUT_2_4_data = 12'd3944;
                234: O_LUT_2_4_data = 12'd3951;
                235: O_LUT_2_4_data = 12'd3958;
                236: O_LUT_2_4_data = 12'd3965;
                237: O_LUT_2_4_data = 12'd3971;
                238: O_LUT_2_4_data = 12'd3978;
                239: O_LUT_2_4_data = 12'd3985;
                240: O_LUT_2_4_data = 12'd3992;
                241: O_LUT_2_4_data = 12'd3999;
                242: O_LUT_2_4_data = 12'd4006;
                243: O_LUT_2_4_data = 12'd4012;
                244: O_LUT_2_4_data = 12'd4019;
                245: O_LUT_2_4_data = 12'd4026;
                246: O_LUT_2_4_data = 12'd4032;
                247: O_LUT_2_4_data = 12'd4039;
                248: O_LUT_2_4_data = 12'd4046;
                249: O_LUT_2_4_data = 12'd4053;
                250: O_LUT_2_4_data = 12'd4059;
                251: O_LUT_2_4_data = 12'd4066;
                252: O_LUT_2_4_data = 12'd4072;
                253: O_LUT_2_4_data = 12'd4079;
                254: O_LUT_2_4_data = 12'd4086;
                255: O_LUT_2_4_data = 12'd4092;
            default: O_LUT_2_4_data = 12'd4092;
        endcase
    end




endmodule