/*******************************MILIANKE*******************************
*Company : MiLianKe Electronic Technology Co., Ltd.
*WebSite:https://www.milianke.com
*TechWeb:https://www.uisrc.com
*tmall-shop:https://milianke.tmall.com
*jd-shop:https://milianke.jd.com
*taobao-shop1: https://milianke.taobao.com
*Create Date: 2024/10/23
*Module Name:
*File Name:
*Description: 
*The reference demo provided by Milianke is only used for learning. 
*We cannot ensure that the demo itself is free of bugs, so users 
*should be responsible for the technical problems and consequences
*caused by the use of their own products.
*Copyright: Copyright (c) MiLianKe
*All rights reserved.
*Revision: 1.0
*Signal description
*1) I_ input
*2) O_ output
*3) IO_ input output
*4) S_ system internal signal
*5) _n activ low
*6) _dg debug signal 
*7) _r delay or register
*8) _s state mechine
*********************************************************************/
/*********ui_lut_2_6 ********************************************
@Description :   GAMMA=2.6
*****************************************************************/
module ui_lut_2_6 (
    input                    I_clk  ,
    input                    I_rst_n,

    input      [7:0]         I_LUT_2_6_data  ,
    output reg [11:0]        O_LUT_2_6_data  
);
    
    always @(*)begin 
        case (I_LUT_2_6_data)
                0:   O_LUT_2_6_data = 12'd373;
                1:   O_LUT_2_6_data = 12'd569;
                2:   O_LUT_2_6_data = 12'd692;
                3:   O_LUT_2_6_data = 12'd787;
                4:   O_LUT_2_6_data = 12'd867;
                5:   O_LUT_2_6_data = 12'd937;
                6:   O_LUT_2_6_data = 12'd999;
                7:   O_LUT_2_6_data = 12'd1055;
                8:   O_LUT_2_6_data = 12'd1107;
                9:   O_LUT_2_6_data = 12'd1156;
                10:  O_LUT_2_6_data = 12'd1201;
                11:  O_LUT_2_6_data = 12'd1244;
                12:  O_LUT_2_6_data = 12'd1284;
                13:  O_LUT_2_6_data = 12'd1323;
                14:  O_LUT_2_6_data = 12'd1360;
                15:  O_LUT_2_6_data = 12'd1395;
                16:  O_LUT_2_6_data = 12'd1429;
                17:  O_LUT_2_6_data = 12'd1461;
                18:  O_LUT_2_6_data = 12'd1493;
                19:  O_LUT_2_6_data = 12'd1523;
                20:  O_LUT_2_6_data = 12'd1553;
                21:  O_LUT_2_6_data = 12'd1582;
                22:  O_LUT_2_6_data = 12'd1610;
                23:  O_LUT_2_6_data = 12'd1637;
                24:  O_LUT_2_6_data = 12'd1663;
                25:  O_LUT_2_6_data = 12'd1689;
                26:  O_LUT_2_6_data = 12'd1714;
                27:  O_LUT_2_6_data = 12'd1738;
                28:  O_LUT_2_6_data = 12'd1763;
                29:  O_LUT_2_6_data = 12'd1786;
                30:  O_LUT_2_6_data = 12'd1809;
                31:  O_LUT_2_6_data = 12'd1832;
                32:  O_LUT_2_6_data = 12'd1854;
                33:  O_LUT_2_6_data = 12'd1875;
                34:  O_LUT_2_6_data = 12'd1897;
                35:  O_LUT_2_6_data = 12'd1918;
                36:  O_LUT_2_6_data = 12'd1938;
                37:  O_LUT_2_6_data = 12'd1958;
                38:  O_LUT_2_6_data = 12'd1978;
                39:  O_LUT_2_6_data = 12'd1998;
                40:  O_LUT_2_6_data = 12'd2017;
                41:  O_LUT_2_6_data = 12'd2036;
                42:  O_LUT_2_6_data = 12'd2055;
                43:  O_LUT_2_6_data = 12'd2073;
                44:  O_LUT_2_6_data = 12'd2092;
                45:  O_LUT_2_6_data = 12'd2109;
                46:  O_LUT_2_6_data = 12'd2127;
                47:  O_LUT_2_6_data = 12'd2145;
                48:  O_LUT_2_6_data = 12'd2162;
                49:  O_LUT_2_6_data = 12'd2179;
                50:  O_LUT_2_6_data = 12'd2196;
                51:  O_LUT_2_6_data = 12'd2212;
                52:  O_LUT_2_6_data = 12'd2229;
                53:  O_LUT_2_6_data = 12'd2245;
                54:  O_LUT_2_6_data = 12'd2261;
                55:  O_LUT_2_6_data = 12'd2277;
                56:  O_LUT_2_6_data = 12'd2292;
                57:  O_LUT_2_6_data = 12'd2308;
                58:  O_LUT_2_6_data = 12'd2323;
                59:  O_LUT_2_6_data = 12'd2338;
                60:  O_LUT_2_6_data = 12'd2353;
                61:  O_LUT_2_6_data = 12'd2368;
                62:  O_LUT_2_6_data = 12'd2383;
                63:  O_LUT_2_6_data = 12'd2398;
                64:  O_LUT_2_6_data = 12'd2412;
                65:  O_LUT_2_6_data = 12'd2426;
                66:  O_LUT_2_6_data = 12'd2440;
                67:  O_LUT_2_6_data = 12'd2454;
                68:  O_LUT_2_6_data = 12'd2468;
                69:  O_LUT_2_6_data = 12'd2482;
                70:  O_LUT_2_6_data = 12'd2496;
                71:  O_LUT_2_6_data = 12'd2509;
                72:  O_LUT_2_6_data = 12'd2523;
                73:  O_LUT_2_6_data = 12'd2536;
                74:  O_LUT_2_6_data = 12'd2549;
                75:  O_LUT_2_6_data = 12'd2562;
                76:  O_LUT_2_6_data = 12'd2575;
                77:  O_LUT_2_6_data = 12'd2588;
                78:  O_LUT_2_6_data = 12'd2601;
                79:  O_LUT_2_6_data = 12'd2614;
                80:  O_LUT_2_6_data = 12'd2626;
                81:  O_LUT_2_6_data = 12'd2639;
                82:  O_LUT_2_6_data = 12'd2651;
                83:  O_LUT_2_6_data = 12'd2663;
                84:  O_LUT_2_6_data = 12'd2676;
                85:  O_LUT_2_6_data = 12'd2688;
                86:  O_LUT_2_6_data = 12'd2700;
                87:  O_LUT_2_6_data = 12'd2712;
                88:  O_LUT_2_6_data = 12'd2724;
                89:  O_LUT_2_6_data = 12'd2735;
                90:  O_LUT_2_6_data = 12'd2747;
                91:  O_LUT_2_6_data = 12'd2759;
                92:  O_LUT_2_6_data = 12'd2770;
                93:  O_LUT_2_6_data = 12'd2782;
                94:  O_LUT_2_6_data = 12'd2793;
                95:  O_LUT_2_6_data = 12'd2804;
                96:  O_LUT_2_6_data = 12'd2816;
                97:  O_LUT_2_6_data = 12'd2827;
                98:  O_LUT_2_6_data = 12'd2838;
                99:  O_LUT_2_6_data = 12'd2849;
                100: O_LUT_2_6_data = 12'd2860;
                101: O_LUT_2_6_data = 12'd2871;
                102: O_LUT_2_6_data = 12'd2882;
                103: O_LUT_2_6_data = 12'd2892;
                104: O_LUT_2_6_data = 12'd2903;
                105: O_LUT_2_6_data = 12'd2914;
                106: O_LUT_2_6_data = 12'd2924;
                107: O_LUT_2_6_data = 12'd2935;
                108: O_LUT_2_6_data = 12'd2945;
                109: O_LUT_2_6_data = 12'd2956;
                110: O_LUT_2_6_data = 12'd2966;
                111: O_LUT_2_6_data = 12'd2976;
                112: O_LUT_2_6_data = 12'd2987;
                113: O_LUT_2_6_data = 12'd2997;
                114: O_LUT_2_6_data = 12'd3007;
                115: O_LUT_2_6_data = 12'd3017;
                116: O_LUT_2_6_data = 12'd3027;
                117: O_LUT_2_6_data = 12'd3037;
                118: O_LUT_2_6_data = 12'd3047;
                119: O_LUT_2_6_data = 12'd3057;
                120: O_LUT_2_6_data = 12'd3066;
                121: O_LUT_2_6_data = 12'd3076;
                122: O_LUT_2_6_data = 12'd3086;
                123: O_LUT_2_6_data = 12'd3095;
                124: O_LUT_2_6_data = 12'd3105;
                125: O_LUT_2_6_data = 12'd3115;
                126: O_LUT_2_6_data = 12'd3124;
                127: O_LUT_2_6_data = 12'd3134;
                128: O_LUT_2_6_data = 12'd3143;
                129: O_LUT_2_6_data = 12'd3152;
                130: O_LUT_2_6_data = 12'd3162;
                131: O_LUT_2_6_data = 12'd3171;
                132: O_LUT_2_6_data = 12'd3180;
                133: O_LUT_2_6_data = 12'd3189;
                134: O_LUT_2_6_data = 12'd3199;
                135: O_LUT_2_6_data = 12'd3208;
                136: O_LUT_2_6_data = 12'd3217;
                137: O_LUT_2_6_data = 12'd3226;
                138: O_LUT_2_6_data = 12'd3235;
                139: O_LUT_2_6_data = 12'd3244;
                140: O_LUT_2_6_data = 12'd3253;
                141: O_LUT_2_6_data = 12'd3262;
                142: O_LUT_2_6_data = 12'd3270;
                143: O_LUT_2_6_data = 12'd3279;
                144: O_LUT_2_6_data = 12'd3288;
                145: O_LUT_2_6_data = 12'd3297;
                146: O_LUT_2_6_data = 12'd3305;
                147: O_LUT_2_6_data = 12'd3314;
                148: O_LUT_2_6_data = 12'd3323;
                149: O_LUT_2_6_data = 12'd3331;
                150: O_LUT_2_6_data = 12'd3340;
                151: O_LUT_2_6_data = 12'd3348;
                152: O_LUT_2_6_data = 12'd3357;
                153: O_LUT_2_6_data = 12'd3365;
                154: O_LUT_2_6_data = 12'd3373;
                155: O_LUT_2_6_data = 12'd3382;
                156: O_LUT_2_6_data = 12'd3390;
                157: O_LUT_2_6_data = 12'd3399;
                158: O_LUT_2_6_data = 12'd3407;
                159: O_LUT_2_6_data = 12'd3415;
                160: O_LUT_2_6_data = 12'd3423;
                161: O_LUT_2_6_data = 12'd3431;
                162: O_LUT_2_6_data = 12'd3440;
                163: O_LUT_2_6_data = 12'd3448;
                164: O_LUT_2_6_data = 12'd3456;
                165: O_LUT_2_6_data = 12'd3464;
                166: O_LUT_2_6_data = 12'd3472;
                167: O_LUT_2_6_data = 12'd3480;
                168: O_LUT_2_6_data = 12'd3488;
                169: O_LUT_2_6_data = 12'd3496;
                170: O_LUT_2_6_data = 12'd3504;
                171: O_LUT_2_6_data = 12'd3511;
                172: O_LUT_2_6_data = 12'd3519;
                173: O_LUT_2_6_data = 12'd3527;
                174: O_LUT_2_6_data = 12'd3535;
                175: O_LUT_2_6_data = 12'd3543;
                176: O_LUT_2_6_data = 12'd3550;
                177: O_LUT_2_6_data = 12'd3558;
                178: O_LUT_2_6_data = 12'd3566;
                179: O_LUT_2_6_data = 12'd3574;
                180: O_LUT_2_6_data = 12'd3581;
                181: O_LUT_2_6_data = 12'd3589;
                182: O_LUT_2_6_data = 12'd3596;
                183: O_LUT_2_6_data = 12'd3604;
                184: O_LUT_2_6_data = 12'd3611;
                185: O_LUT_2_6_data = 12'd3619;
                186: O_LUT_2_6_data = 12'd3626;
                187: O_LUT_2_6_data = 12'd3634;
                188: O_LUT_2_6_data = 12'd3641;
                189: O_LUT_2_6_data = 12'd3649;
                190: O_LUT_2_6_data = 12'd3656;
                191: O_LUT_2_6_data = 12'd3663;
                192: O_LUT_2_6_data = 12'd3671;
                193: O_LUT_2_6_data = 12'd3678;
                194: O_LUT_2_6_data = 12'd3685;
                195: O_LUT_2_6_data = 12'd3693;
                196: O_LUT_2_6_data = 12'd3700;
                197: O_LUT_2_6_data = 12'd3707;
                198: O_LUT_2_6_data = 12'd3714;
                199: O_LUT_2_6_data = 12'd3721;
                200: O_LUT_2_6_data = 12'd3729;
                201: O_LUT_2_6_data = 12'd3736;
                202: O_LUT_2_6_data = 12'd3743;
                203: O_LUT_2_6_data = 12'd3750;
                204: O_LUT_2_6_data = 12'd3757;
                205: O_LUT_2_6_data = 12'd3764;
                206: O_LUT_2_6_data = 12'd3771;
                207: O_LUT_2_6_data = 12'd3778;
                208: O_LUT_2_6_data = 12'd3785;
                209: O_LUT_2_6_data = 12'd3792;
                210: O_LUT_2_6_data = 12'd3799;
                211: O_LUT_2_6_data = 12'd3806;
                212: O_LUT_2_6_data = 12'd3813;
                213: O_LUT_2_6_data = 12'd3820;
                214: O_LUT_2_6_data = 12'd3827;
                215: O_LUT_2_6_data = 12'd3833;
                216: O_LUT_2_6_data = 12'd3840;
                217: O_LUT_2_6_data = 12'd3847;
                218: O_LUT_2_6_data = 12'd3854;
                219: O_LUT_2_6_data = 12'd3861;
                220: O_LUT_2_6_data = 12'd3867;
                221: O_LUT_2_6_data = 12'd3874;
                222: O_LUT_2_6_data = 12'd3881;
                223: O_LUT_2_6_data = 12'd3887;
                224: O_LUT_2_6_data = 12'd3894;
                225: O_LUT_2_6_data = 12'd3901;
                226: O_LUT_2_6_data = 12'd3907;
                227: O_LUT_2_6_data = 12'd3914;
                228: O_LUT_2_6_data = 12'd3921;
                229: O_LUT_2_6_data = 12'd3927;
                230: O_LUT_2_6_data = 12'd3934;
                231: O_LUT_2_6_data = 12'd3940;
                232: O_LUT_2_6_data = 12'd3947;
                233: O_LUT_2_6_data = 12'd3953;
                234: O_LUT_2_6_data = 12'd3960;
                235: O_LUT_2_6_data = 12'd3966;
                236: O_LUT_2_6_data = 12'd3973;
                237: O_LUT_2_6_data = 12'd3979;
                238: O_LUT_2_6_data = 12'd3986;
                239: O_LUT_2_6_data = 12'd3992;
                240: O_LUT_2_6_data = 12'd3998;
                241: O_LUT_2_6_data = 12'd4005;
                242: O_LUT_2_6_data = 12'd4011;
                243: O_LUT_2_6_data = 12'd4018;
                244: O_LUT_2_6_data = 12'd4024;
                245: O_LUT_2_6_data = 12'd4030;
                246: O_LUT_2_6_data = 12'd4036;
                247: O_LUT_2_6_data = 12'd4043;
                248: O_LUT_2_6_data = 12'd4049;
                249: O_LUT_2_6_data = 12'd4055;
                250: O_LUT_2_6_data = 12'd4061;
                251: O_LUT_2_6_data = 12'd4068;
                252: O_LUT_2_6_data = 12'd4074;
                253: O_LUT_2_6_data = 12'd4080;
                254: O_LUT_2_6_data = 12'd4086;
                255: O_LUT_2_6_data = 12'd4092;
            default: O_LUT_2_6_data = 12'd4092;
        endcase
    end




endmodule