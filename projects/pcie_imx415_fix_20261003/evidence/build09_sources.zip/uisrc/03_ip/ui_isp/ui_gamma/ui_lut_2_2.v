/*******************************MILIANKE*******************************
*Company : MiLianKe Electronic Technology Co., Ltd.
*WebSite:https://www.milianke.com
*TechWeb:https://www.uisrc.com
*tmall-shop:https://milianke.tmall.com
*jd-shop:https://milianke.jd.com
*taobao-shop1: https://milianke.taobao.com
*Create Date: 2024/10/23
*Module Name:
*File Name:
*Description: 
*The reference demo provided by Milianke is only used for learning. 
*We cannot ensure that the demo itself is free of bugs, so users 
*should be responsible for the technical problems and consequences
*caused by the use of their own products.
*Copyright: Copyright (c) MiLianKe
*All rights reserved.
*Revision: 1.0
*Signal description
*1) I_ input
*2) O_ output
*3) IO_ input output
*4) S_ system internal signal
*5) _n activ low
*6) _dg debug signal 
*7) _r delay or register
*8) _s state mechine
*********************************************************************/
/*********ui_lut_2_2 ********************************************
@Description :   GAMMA=2.2
*****************************************************************/
module ui_lut_2_2 (
    input                    I_clk  ,
    input                    I_rst_n,

    input      [7:0]              I_LUT_2_2_data  ,
    output reg [11:0]              O_LUT_2_2_data  
);
    
    always @(*)begin 
        case (I_LUT_2_2_data)
                0:   O_LUT_2_2_data = 12'd240; 
                1:   O_LUT_2_2_data = 12'd396; 
                2:   O_LUT_2_2_data = 12'd499; 
                3:   O_LUT_2_2_data = 12'd582; 
                4:   O_LUT_2_2_data = 12'd652; 
                5:   O_LUT_2_2_data = 12'd715; 
                6:   O_LUT_2_2_data = 12'd771; 
                7:   O_LUT_2_2_data = 12'd823; 
                8:   O_LUT_2_2_data = 12'd871; 
                9:   O_LUT_2_2_data = 12'd916; 
                10:  O_LUT_2_2_data = 12'd959; 
                11:  O_LUT_2_2_data = 12'd999; 
                12:  O_LUT_2_2_data = 12'd1038;
                13:  O_LUT_2_2_data = 12'd1075;
                14:  O_LUT_2_2_data = 12'd1110;
                15:  O_LUT_2_2_data = 12'd1145;
                16:  O_LUT_2_2_data = 12'd1178;
                17:  O_LUT_2_2_data = 12'd1209;
                18:  O_LUT_2_2_data = 12'd1240;
                19:  O_LUT_2_2_data = 12'd1270;
                20:  O_LUT_2_2_data = 12'd1300;
                21:  O_LUT_2_2_data = 12'd1328;
                22:  O_LUT_2_2_data = 12'd1356;
                23:  O_LUT_2_2_data = 12'd1383;
                24:  O_LUT_2_2_data = 12'd1409;
                25:  O_LUT_2_2_data = 12'd1435;
                26:  O_LUT_2_2_data = 12'd1461;
                27:  O_LUT_2_2_data = 12'd1485;
                28:  O_LUT_2_2_data = 12'd1510;
                29:  O_LUT_2_2_data = 12'd1534;
                30:  O_LUT_2_2_data = 12'd1557;
                31:  O_LUT_2_2_data = 12'd1580;
                32:  O_LUT_2_2_data = 12'd1603;
                33:  O_LUT_2_2_data = 12'd1625;
                34:  O_LUT_2_2_data = 12'd1647;
                35:  O_LUT_2_2_data = 12'd1668;
                36:  O_LUT_2_2_data = 12'd1689;
                37:  O_LUT_2_2_data = 12'd1710;
                38:  O_LUT_2_2_data = 12'd1731;
                39:  O_LUT_2_2_data = 12'd1751;
                40:  O_LUT_2_2_data = 12'd1771;
                41:  O_LUT_2_2_data = 12'd1791;
                42:  O_LUT_2_2_data = 12'd1810;
                43:  O_LUT_2_2_data = 12'd1830;
                44:  O_LUT_2_2_data = 12'd1849;
                45:  O_LUT_2_2_data = 12'd1868;
                46:  O_LUT_2_2_data = 12'd1886;
                47:  O_LUT_2_2_data = 12'd1904;
                48:  O_LUT_2_2_data = 12'd1923;
                49:  O_LUT_2_2_data = 12'd1940;
                50:  O_LUT_2_2_data = 12'd1958;
                51:  O_LUT_2_2_data = 12'd1976;
                52:  O_LUT_2_2_data = 12'd1993;
                53:  O_LUT_2_2_data = 12'd2010;
                54:  O_LUT_2_2_data = 12'd2027;
                55:  O_LUT_2_2_data = 12'd2044;
                56:  O_LUT_2_2_data = 12'd2061;
                57:  O_LUT_2_2_data = 12'd2077;
                58:  O_LUT_2_2_data = 12'd2094;
                59:  O_LUT_2_2_data = 12'd2110;
                60:  O_LUT_2_2_data = 12'd2126;
                61:  O_LUT_2_2_data = 12'd2142;
                62:  O_LUT_2_2_data = 12'd2157;
                63:  O_LUT_2_2_data = 12'd2173;
                64:  O_LUT_2_2_data = 12'd2189;
                65:  O_LUT_2_2_data = 12'd2204;
                66:  O_LUT_2_2_data = 12'd2219;
                67:  O_LUT_2_2_data = 12'd2234;
                68:  O_LUT_2_2_data = 12'd2249;
                69:  O_LUT_2_2_data = 12'd2264;
                70:  O_LUT_2_2_data = 12'd2279;
                71:  O_LUT_2_2_data = 12'd2294;
                72:  O_LUT_2_2_data = 12'd2308;
                73:  O_LUT_2_2_data = 12'd2322;
                74:  O_LUT_2_2_data = 12'd2337;
                75:  O_LUT_2_2_data = 12'd2351;
                76:  O_LUT_2_2_data = 12'd2365;
                77:  O_LUT_2_2_data = 12'd2379;
                78:  O_LUT_2_2_data = 12'd2393;
                79:  O_LUT_2_2_data = 12'd2407;
                80:  O_LUT_2_2_data = 12'd2421;
                81:  O_LUT_2_2_data = 12'd2434;
                82:  O_LUT_2_2_data = 12'd2448;
                83:  O_LUT_2_2_data = 12'd2461;
                84:  O_LUT_2_2_data = 12'd2474;
                85:  O_LUT_2_2_data = 12'd2488;
                86:  O_LUT_2_2_data = 12'd2501;
                87:  O_LUT_2_2_data = 12'd2514;
                88:  O_LUT_2_2_data = 12'd2527;
                89:  O_LUT_2_2_data = 12'd2540;
                90:  O_LUT_2_2_data = 12'd2553;
                91:  O_LUT_2_2_data = 12'd2566;
                92:  O_LUT_2_2_data = 12'd2578;
                93:  O_LUT_2_2_data = 12'd2591;
                94:  O_LUT_2_2_data = 12'd2604;
                95:  O_LUT_2_2_data = 12'd2616;
                96:  O_LUT_2_2_data = 12'd2628;
                97:  O_LUT_2_2_data = 12'd2641;
                98:  O_LUT_2_2_data = 12'd2653;
                99:  O_LUT_2_2_data = 12'd2665;
                100: O_LUT_2_2_data = 12'd2677;
                101: O_LUT_2_2_data = 12'd2690;
                102: O_LUT_2_2_data = 12'd2702;
                103: O_LUT_2_2_data = 12'd2713;
                104: O_LUT_2_2_data = 12'd2725;
                105: O_LUT_2_2_data = 12'd2737;
                106: O_LUT_2_2_data = 12'd2749;
                107: O_LUT_2_2_data = 12'd2761;
                108: O_LUT_2_2_data = 12'd2772;
                109: O_LUT_2_2_data = 12'd2784;
                110: O_LUT_2_2_data = 12'd2795;
                111: O_LUT_2_2_data = 12'd2807;
                112: O_LUT_2_2_data = 12'd2818;
                113: O_LUT_2_2_data = 12'd2830;
                114: O_LUT_2_2_data = 12'd2841;
                115: O_LUT_2_2_data = 12'd2852;
                116: O_LUT_2_2_data = 12'd2863;
                117: O_LUT_2_2_data = 12'd2875;
                118: O_LUT_2_2_data = 12'd2886;
                119: O_LUT_2_2_data = 12'd2897;
                120: O_LUT_2_2_data = 12'd2908;
                121: O_LUT_2_2_data = 12'd2919;
                122: O_LUT_2_2_data = 12'd2930;
                123: O_LUT_2_2_data = 12'd2940;
                124: O_LUT_2_2_data = 12'd2951;
                125: O_LUT_2_2_data = 12'd2962;
                126: O_LUT_2_2_data = 12'd2973;
                127: O_LUT_2_2_data = 12'd2983;
                128: O_LUT_2_2_data = 12'd2994;
                129: O_LUT_2_2_data = 12'd3004;
                130: O_LUT_2_2_data = 12'd3015;
                131: O_LUT_2_2_data = 12'd3025;
                132: O_LUT_2_2_data = 12'd3036;
                133: O_LUT_2_2_data = 12'd3046;
                134: O_LUT_2_2_data = 12'd3057;
                135: O_LUT_2_2_data = 12'd3067;
                136: O_LUT_2_2_data = 12'd3077;
                137: O_LUT_2_2_data = 12'd3087;
                138: O_LUT_2_2_data = 12'd3098;
                139: O_LUT_2_2_data = 12'd3108;
                140: O_LUT_2_2_data = 12'd3118;
                141: O_LUT_2_2_data = 12'd3128;
                142: O_LUT_2_2_data = 12'd3138;
                143: O_LUT_2_2_data = 12'd3148;
                144: O_LUT_2_2_data = 12'd3158;
                145: O_LUT_2_2_data = 12'd3168;
                146: O_LUT_2_2_data = 12'd3178;
                147: O_LUT_2_2_data = 12'd3188;
                148: O_LUT_2_2_data = 12'd3197;
                149: O_LUT_2_2_data = 12'd3207;
                150: O_LUT_2_2_data = 12'd3217;
                151: O_LUT_2_2_data = 12'd3227;
                152: O_LUT_2_2_data = 12'd3236;
                153: O_LUT_2_2_data = 12'd3246;
                154: O_LUT_2_2_data = 12'd3255;
                155: O_LUT_2_2_data = 12'd3265;
                156: O_LUT_2_2_data = 12'd3275;
                157: O_LUT_2_2_data = 12'd3284;
                158: O_LUT_2_2_data = 12'd3294;
                159: O_LUT_2_2_data = 12'd3303;
                160: O_LUT_2_2_data = 12'd3312;
                161: O_LUT_2_2_data = 12'd3322;
                162: O_LUT_2_2_data = 12'd3331;
                163: O_LUT_2_2_data = 12'd3340;
                164: O_LUT_2_2_data = 12'd3350;
                165: O_LUT_2_2_data = 12'd3359;
                166: O_LUT_2_2_data = 12'd3368;
                167: O_LUT_2_2_data = 12'd3377;
                168: O_LUT_2_2_data = 12'd3386;
                169: O_LUT_2_2_data = 12'd3396;
                170: O_LUT_2_2_data = 12'd3405;
                171: O_LUT_2_2_data = 12'd3414;
                172: O_LUT_2_2_data = 12'd3423;
                173: O_LUT_2_2_data = 12'd3432;
                174: O_LUT_2_2_data = 12'd3441;
                175: O_LUT_2_2_data = 12'd3450;
                176: O_LUT_2_2_data = 12'd3459;
                177: O_LUT_2_2_data = 12'd3467;
                178: O_LUT_2_2_data = 12'd3476;
                179: O_LUT_2_2_data = 12'd3485;
                180: O_LUT_2_2_data = 12'd3494;
                181: O_LUT_2_2_data = 12'd3503;
                182: O_LUT_2_2_data = 12'd3512;
                183: O_LUT_2_2_data = 12'd3520;
                184: O_LUT_2_2_data = 12'd3529;
                185: O_LUT_2_2_data = 12'd3538;
                186: O_LUT_2_2_data = 12'd3546;
                187: O_LUT_2_2_data = 12'd3555;
                188: O_LUT_2_2_data = 12'd3564;
                189: O_LUT_2_2_data = 12'd3572;
                190: O_LUT_2_2_data = 12'd3581;
                191: O_LUT_2_2_data = 12'd3589;
                192: O_LUT_2_2_data = 12'd3598;
                193: O_LUT_2_2_data = 12'd3606;
                194: O_LUT_2_2_data = 12'd3615;
                195: O_LUT_2_2_data = 12'd3623;
                196: O_LUT_2_2_data = 12'd3632;
                197: O_LUT_2_2_data = 12'd3640;
                198: O_LUT_2_2_data = 12'd3648;
                199: O_LUT_2_2_data = 12'd3657;
                200: O_LUT_2_2_data = 12'd3665;
                201: O_LUT_2_2_data = 12'd3673;
                202: O_LUT_2_2_data = 12'd3682;
                203: O_LUT_2_2_data = 12'd3690;
                204: O_LUT_2_2_data = 12'd3698;
                205: O_LUT_2_2_data = 12'd3706;
                206: O_LUT_2_2_data = 12'd3714;
                207: O_LUT_2_2_data = 12'd3723;
                208: O_LUT_2_2_data = 12'd3731;
                209: O_LUT_2_2_data = 12'd3739;
                210: O_LUT_2_2_data = 12'd3747;
                211: O_LUT_2_2_data = 12'd3755;
                212: O_LUT_2_2_data = 12'd3763;
                213: O_LUT_2_2_data = 12'd3771;
                214: O_LUT_2_2_data = 12'd3779;
                215: O_LUT_2_2_data = 12'd3787;
                216: O_LUT_2_2_data = 12'd3795;
                217: O_LUT_2_2_data = 12'd3803;
                218: O_LUT_2_2_data = 12'd3811;
                219: O_LUT_2_2_data = 12'd3819;
                220: O_LUT_2_2_data = 12'd3827;
                221: O_LUT_2_2_data = 12'd3835;
                222: O_LUT_2_2_data = 12'd3843;
                223: O_LUT_2_2_data = 12'd3850;
                224: O_LUT_2_2_data = 12'd3858;
                225: O_LUT_2_2_data = 12'd3866;
                226: O_LUT_2_2_data = 12'd3874;
                227: O_LUT_2_2_data = 12'd3882;
                228: O_LUT_2_2_data = 12'd3889;
                229: O_LUT_2_2_data = 12'd3897;
                230: O_LUT_2_2_data = 12'd3905;
                231: O_LUT_2_2_data = 12'd3912;
                232: O_LUT_2_2_data = 12'd3920;
                233: O_LUT_2_2_data = 12'd3928;
                234: O_LUT_2_2_data = 12'd3935;
                235: O_LUT_2_2_data = 12'd3943;
                236: O_LUT_2_2_data = 12'd3951;
                237: O_LUT_2_2_data = 12'd3958;
                238: O_LUT_2_2_data = 12'd3966;
                239: O_LUT_2_2_data = 12'd3973;
                240: O_LUT_2_2_data = 12'd3981;
                241: O_LUT_2_2_data = 12'd3988;
                242: O_LUT_2_2_data = 12'd3996;
                243: O_LUT_2_2_data = 12'd4003;
                244: O_LUT_2_2_data = 12'd4011;
                245: O_LUT_2_2_data = 12'd4018;
                246: O_LUT_2_2_data = 12'd4026;
                247: O_LUT_2_2_data = 12'd4033;
                248: O_LUT_2_2_data = 12'd4041;
                249: O_LUT_2_2_data = 12'd4048;
                250: O_LUT_2_2_data = 12'd4055;
                251: O_LUT_2_2_data = 12'd4063;
                252: O_LUT_2_2_data = 12'd4070;
                253: O_LUT_2_2_data = 12'd4077;
                254: O_LUT_2_2_data = 12'd4085;
                255: O_LUT_2_2_data = 12'd4092;
            default: O_LUT_2_2_data = 12'd4092;
        endcase
    end




endmodule