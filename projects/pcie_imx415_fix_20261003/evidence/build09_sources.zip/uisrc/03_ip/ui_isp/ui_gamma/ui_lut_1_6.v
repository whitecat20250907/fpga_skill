/*******************************MILIANKE*******************************
*Company : MiLianKe Electronic Technology Co., Ltd.
*WebSite:https://www.milianke.com
*TechWeb:https://www.uisrc.com
*tmall-shop:https://milianke.tmall.com
*jd-shop:https://milianke.jd.com
*taobao-shop1: https://milianke.taobao.com
*Create Date: 2024/10/23
*Module Name:
*File Name:
*Description: 
*The reference demo provided by Milianke is only used for learning. 
*We cannot ensure that the demo itself is free of bugs, so users 
*should be responsible for the technical problems and consequences
*caused by the use of their own products.
*Copyright: Copyright (c) MiLianKe
*All rights reserved.
*Revision: 1.0
*Signal description
*1) I_ input
*2) O_ output
*3) IO_ input output
*4) S_ system internal signal
*5) _n activ low
*6) _dg debug signal 
*7) _r delay or register
*8) _s state mechine
*********************************************************************/
/*********ui_lut_1_6 ********************************************
@Description :   gamma=1.6
*****************************************************************/
module ui_lut_1_6 (
    input                    I_clk  ,
    input                    I_rst_n,

    input      [7:0]               I_LUT_1_6_data  ,
    output reg [11:0]              O_LUT_1_6_data  
);

    always @(*)begin 
        case (I_LUT_1_6_data)
                0:  O_LUT_1_6_data = 12'd82 ;
                1:  O_LUT_1_6_data = 12'd164;
                2:  O_LUT_1_6_data = 12'd226;
                3:  O_LUT_1_6_data = 12'd280;
                4:  O_LUT_1_6_data = 12'd327;
                5:  O_LUT_1_6_data = 12'd371;
                6:  O_LUT_1_6_data = 12'd412;
                7:  O_LUT_1_6_data = 12'd450;
                8:  O_LUT_1_6_data = 12'd487;
                9:  O_LUT_1_6_data = 12'd522;
                10: O_LUT_1_6_data = 12'd556;
                11: O_LUT_1_6_data = 12'd589;
                12: O_LUT_1_6_data = 12'd620;
                13: O_LUT_1_6_data = 12'd651;
                14: O_LUT_1_6_data = 12'd680;
                15: O_LUT_1_6_data = 12'd709;
                16: O_LUT_1_6_data = 12'd738;
                17: O_LUT_1_6_data = 12'd765;
                18: O_LUT_1_6_data = 12'd792;
                19: O_LUT_1_6_data = 12'd819;
                20: O_LUT_1_6_data = 12'd845;
                21: O_LUT_1_6_data = 12'd870;
                22: O_LUT_1_6_data = 12'd896;
                23: O_LUT_1_6_data = 12'd920;
                24: O_LUT_1_6_data = 12'd945;
                25: O_LUT_1_6_data = 12'd968;
                26: O_LUT_1_6_data = 12'd992;
                27: O_LUT_1_6_data = 12'd1015;
                28: O_LUT_1_6_data = 12'd1038;
                29: O_LUT_1_6_data = 12'd1061;
                30: O_LUT_1_6_data = 12'd1083;
                31: O_LUT_1_6_data = 12'd1105;
                32: O_LUT_1_6_data = 12'd1127;
                33: O_LUT_1_6_data = 12'd1149;
                34: O_LUT_1_6_data = 12'd1170;
                35: O_LUT_1_6_data = 12'd1191;
                36: O_LUT_1_6_data = 12'd1212;
                37: O_LUT_1_6_data = 12'd1233;
                38: O_LUT_1_6_data = 12'd1253;
                39: O_LUT_1_6_data = 12'd1273;
                40: O_LUT_1_6_data = 12'd1293;
                41: O_LUT_1_6_data = 12'd1313;
                42: O_LUT_1_6_data = 12'd1333;
                43: O_LUT_1_6_data = 12'd1352;
                44: O_LUT_1_6_data = 12'd1372;
                45: O_LUT_1_6_data = 12'd1391;
                46: O_LUT_1_6_data = 12'd1410;
                47: O_LUT_1_6_data = 12'd1429;
                48: O_LUT_1_6_data = 12'd1448;
                49: O_LUT_1_6_data = 12'd1466;
                50: O_LUT_1_6_data = 12'd1485;
                51: O_LUT_1_6_data = 12'd1503;
                52: O_LUT_1_6_data = 12'd1521;
                53: O_LUT_1_6_data = 12'd1539;
                54: O_LUT_1_6_data = 12'd1557;
                55: O_LUT_1_6_data = 12'd1575;
                56: O_LUT_1_6_data = 12'd1593;
                57: O_LUT_1_6_data = 12'd1610;
                58: O_LUT_1_6_data = 12'd1628;
                59: O_LUT_1_6_data = 12'd1645;
                60: O_LUT_1_6_data = 12'd1662;
                61: O_LUT_1_6_data = 12'd1679;
                62: O_LUT_1_6_data = 12'd1696;
                63: O_LUT_1_6_data = 12'd1713;
                64: O_LUT_1_6_data = 12'd1730;
                65: O_LUT_1_6_data = 12'd1747;
                66: O_LUT_1_6_data = 12'd1763;
                67: O_LUT_1_6_data = 12'd1780;
                68: O_LUT_1_6_data = 12'd1796;
                69: O_LUT_1_6_data = 12'd1813;
                70: O_LUT_1_6_data = 12'd1829;
                71: O_LUT_1_6_data = 12'd1845;
                72: O_LUT_1_6_data = 12'd1861;
                73: O_LUT_1_6_data = 12'd1877;
                74: O_LUT_1_6_data = 12'd1893;
                75: O_LUT_1_6_data = 12'd1909;
                76: O_LUT_1_6_data = 12'd1925;
                77: O_LUT_1_6_data = 12'd1940;
                78: O_LUT_1_6_data = 12'd1956;
                79: O_LUT_1_6_data = 12'd1972;
                80: O_LUT_1_6_data = 12'd1987;
                81: O_LUT_1_6_data = 12'd2003;
                82: O_LUT_1_6_data = 12'd2018;
                83: O_LUT_1_6_data = 12'd2033;
                84: O_LUT_1_6_data = 12'd2048;
                85: O_LUT_1_6_data = 12'd2063;
                86: O_LUT_1_6_data = 12'd2078;
                87: O_LUT_1_6_data = 12'd2093;
                88: O_LUT_1_6_data = 12'd2108;
                89: O_LUT_1_6_data = 12'd2123;
                90: O_LUT_1_6_data = 12'd2138;
                91: O_LUT_1_6_data = 12'd2153;
                92: O_LUT_1_6_data = 12'd2167;
                93: O_LUT_1_6_data = 12'd2182;
                94: O_LUT_1_6_data = 12'd2197;
                95: O_LUT_1_6_data = 12'd2211;
                96: O_LUT_1_6_data = 12'd2226;
                97: O_LUT_1_6_data = 12'd2240;
                98: O_LUT_1_6_data = 12'd2254;
                99: O_LUT_1_6_data = 12'd2269;
                100:O_LUT_1_6_data = 12'd2283;
                101:O_LUT_1_6_data = 12'd2297;
                102:O_LUT_1_6_data = 12'd2311;
                103:O_LUT_1_6_data = 12'd2325;
                104:O_LUT_1_6_data = 12'd2339;
                105:O_LUT_1_6_data = 12'd2353;
                106:O_LUT_1_6_data = 12'd2367;
                107:O_LUT_1_6_data = 12'd2381;
                108:O_LUT_1_6_data = 12'd2395;
                109:O_LUT_1_6_data = 12'd2409;
                110:O_LUT_1_6_data = 12'd2422;
                111:O_LUT_1_6_data = 12'd2436;
                112:O_LUT_1_6_data = 12'd2450;
                113:O_LUT_1_6_data = 12'd2463;
                114:O_LUT_1_6_data = 12'd2477;
                115:O_LUT_1_6_data = 12'd2490;
                116:O_LUT_1_6_data = 12'd2504;
                117:O_LUT_1_6_data = 12'd2517;
                118:O_LUT_1_6_data = 12'd2530;
                119:O_LUT_1_6_data = 12'd2544;
                120:O_LUT_1_6_data = 12'd2557;
                121:O_LUT_1_6_data = 12'd2570;
                122:O_LUT_1_6_data = 12'd2584;
                123:O_LUT_1_6_data = 12'd2597;
                124:O_LUT_1_6_data = 12'd2610;
                125:O_LUT_1_6_data = 12'd2623;
                126:O_LUT_1_6_data = 12'd2636;
                127:O_LUT_1_6_data = 12'd2649;
                128:O_LUT_1_6_data = 12'd2662;
                129:O_LUT_1_6_data = 12'd2675;
                130:O_LUT_1_6_data = 12'd2688;
                131:O_LUT_1_6_data = 12'd2701;
                132:O_LUT_1_6_data = 12'd2713;
                133:O_LUT_1_6_data = 12'd2726;
                134:O_LUT_1_6_data = 12'd2739;
                135:O_LUT_1_6_data = 12'd2752;
                136:O_LUT_1_6_data = 12'd2764;
                137:O_LUT_1_6_data = 12'd2777;
                138:O_LUT_1_6_data = 12'd2790;
                139:O_LUT_1_6_data = 12'd2802;
                140:O_LUT_1_6_data = 12'd2815;
                141:O_LUT_1_6_data = 12'd2827;
                142:O_LUT_1_6_data = 12'd2840;
                143:O_LUT_1_6_data = 12'd2852;
                144:O_LUT_1_6_data = 12'd2865;
                145:O_LUT_1_6_data = 12'd2877;
                146:O_LUT_1_6_data = 12'd2889;
                147:O_LUT_1_6_data = 12'd2902;
                148:O_LUT_1_6_data = 12'd2914;
                149:O_LUT_1_6_data = 12'd2926;
                150:O_LUT_1_6_data = 12'd2938;
                151:O_LUT_1_6_data = 12'd2950;
                152:O_LUT_1_6_data = 12'd2963;
                153:O_LUT_1_6_data = 12'd2975;
                154:O_LUT_1_6_data = 12'd2987;
                155:O_LUT_1_6_data = 12'd2999;
                156:O_LUT_1_6_data = 12'd3011;
                157:O_LUT_1_6_data = 12'd3023;
                158:O_LUT_1_6_data = 12'd3035;
                159:O_LUT_1_6_data = 12'd3047;
                160:O_LUT_1_6_data = 12'd3059;
                161:O_LUT_1_6_data = 12'd3071;
                162:O_LUT_1_6_data = 12'd3083;
                163:O_LUT_1_6_data = 12'd3094;
                164:O_LUT_1_6_data = 12'd3106;
                165:O_LUT_1_6_data = 12'd3118;
                166:O_LUT_1_6_data = 12'd3130;
                167:O_LUT_1_6_data = 12'd3142;
                168:O_LUT_1_6_data = 12'd3153;
                169:O_LUT_1_6_data = 12'd3165;
                170:O_LUT_1_6_data = 12'd3177;
                171:O_LUT_1_6_data = 12'd3188;
                172:O_LUT_1_6_data = 12'd3200;
                173:O_LUT_1_6_data = 12'd3211;
                174:O_LUT_1_6_data = 12'd3223;
                175:O_LUT_1_6_data = 12'd3235;
                176:O_LUT_1_6_data = 12'd3246;
                177:O_LUT_1_6_data = 12'd3258;
                178:O_LUT_1_6_data = 12'd3269;
                179:O_LUT_1_6_data = 12'd3280;
                180:O_LUT_1_6_data = 12'd3292;
                181:O_LUT_1_6_data = 12'd3303;
                182:O_LUT_1_6_data = 12'd3315;
                183:O_LUT_1_6_data = 12'd3326;
                184:O_LUT_1_6_data = 12'd3337;
                185:O_LUT_1_6_data = 12'd3349;
                186:O_LUT_1_6_data = 12'd3360;
                187:O_LUT_1_6_data = 12'd3371;
                188:O_LUT_1_6_data = 12'd3382;
                189:O_LUT_1_6_data = 12'd3394;
                190:O_LUT_1_6_data = 12'd3405;
                191:O_LUT_1_6_data = 12'd3416;
                192:O_LUT_1_6_data = 12'd3427;
                193:O_LUT_1_6_data = 12'd3438;
                194:O_LUT_1_6_data = 12'd3449;
                195:O_LUT_1_6_data = 12'd3460;
                196:O_LUT_1_6_data = 12'd3471;
                197:O_LUT_1_6_data = 12'd3482;
                198:O_LUT_1_6_data = 12'd3493;
                199:O_LUT_1_6_data = 12'd3504;
                200:O_LUT_1_6_data = 12'd3515;
                201:O_LUT_1_6_data = 12'd3526;
                202:O_LUT_1_6_data = 12'd3537;
                203:O_LUT_1_6_data = 12'd3548;
                204:O_LUT_1_6_data = 12'd3559;
                205:O_LUT_1_6_data = 12'd3570;
                206:O_LUT_1_6_data = 12'd3581;
                207:O_LUT_1_6_data = 12'd3592;
                208:O_LUT_1_6_data = 12'd3602;
                209:O_LUT_1_6_data = 12'd3613;
                210:O_LUT_1_6_data = 12'd3624;
                211:O_LUT_1_6_data = 12'd3635;
                212:O_LUT_1_6_data = 12'd3645;
                213:O_LUT_1_6_data = 12'd3656;
                214:O_LUT_1_6_data = 12'd3667;
                215:O_LUT_1_6_data = 12'd3678;
                216:O_LUT_1_6_data = 12'd3688;
                217:O_LUT_1_6_data = 12'd3699;
                218:O_LUT_1_6_data = 12'd3709;
                219:O_LUT_1_6_data = 12'd3720;
                220:O_LUT_1_6_data = 12'd3731;
                221:O_LUT_1_6_data = 12'd3741;
                222:O_LUT_1_6_data = 12'd3752;
                223:O_LUT_1_6_data = 12'd3762;
                224:O_LUT_1_6_data = 12'd3773;
                225:O_LUT_1_6_data = 12'd3783;
                226:O_LUT_1_6_data = 12'd3794;
                227:O_LUT_1_6_data = 12'd3804;
                228:O_LUT_1_6_data = 12'd3815;
                229:O_LUT_1_6_data = 12'd3825;
                230:O_LUT_1_6_data = 12'd3836;
                231:O_LUT_1_6_data = 12'd3846;
                232:O_LUT_1_6_data = 12'd3856;
                233:O_LUT_1_6_data = 12'd3867;
                234:O_LUT_1_6_data = 12'd3877;
                235:O_LUT_1_6_data = 12'd3887;
                236:O_LUT_1_6_data = 12'd3898;
                237:O_LUT_1_6_data = 12'd3908;
                238:O_LUT_1_6_data = 12'd3918;
                239:O_LUT_1_6_data = 12'd3928;
                240:O_LUT_1_6_data = 12'd3939;
                241:O_LUT_1_6_data = 12'd3949;
                242:O_LUT_1_6_data = 12'd3959;
                243:O_LUT_1_6_data = 12'd3969;
                244:O_LUT_1_6_data = 12'd3980;
                245:O_LUT_1_6_data = 12'd3990;
                246:O_LUT_1_6_data = 12'd4000;
                247:O_LUT_1_6_data = 12'd4010;
                248:O_LUT_1_6_data = 12'd4020;
                249:O_LUT_1_6_data = 12'd4030;
                250:O_LUT_1_6_data = 12'd4040;
                251:O_LUT_1_6_data = 12'd4050;
                252:O_LUT_1_6_data = 12'd4060;
                253:O_LUT_1_6_data = 12'd4070;
                254:O_LUT_1_6_data = 12'd4080;
                255:O_LUT_1_6_data = 12'd4090;
            default:O_LUT_1_6_data = 12'd4092;
        endcase
    end
    
endmodule