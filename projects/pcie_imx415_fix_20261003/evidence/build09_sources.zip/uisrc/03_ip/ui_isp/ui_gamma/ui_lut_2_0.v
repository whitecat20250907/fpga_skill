/*******************************MILIANKE*******************************
*Company : MiLianKe Electronic Technology Co., Ltd.
*WebSite:https://www.milianke.com
*TechWeb:https://www.uisrc.com
*tmall-shop:https://milianke.tmall.com
*jd-shop:https://milianke.jd.com
*taobao-shop1: https://milianke.taobao.com
*Create Date: 2024/10/23
*Module Name:
*File Name:
*Description: 
*The reference demo provided by Milianke is only used for learning. 
*We cannot ensure that the demo itself is free of bugs, so users 
*should be responsible for the technical problems and consequences
*caused by the use of their own products.
*Copyright: Copyright (c) MiLianKe
*All rights reserved.
*Revision: 1.0
*Signal description
*1) I_ input
*2) O_ output
*3) IO_ input output
*4) S_ system internal signal
*5) _n activ low
*6) _dg debug signal 
*7) _r delay or register
*8) _s state mechine
*********************************************************************/
/*********ui_lut_2_0 ********************************************
@Description :   gamma=2.0
*****************************************************************/
module ui_lut_2_0 (
    input                    I_clk  ,
    input                    I_rst_n,

    input      [7:0]               I_LUT_2_0_data  ,
    output reg [11:0]              O_LUT_2_0_data  
);

    always @(*)begin 
        case (I_LUT_2_0_data)
                0:   O_LUT_2_0_data = 12'd181;
                1:   O_LUT_2_0_data = 12'd313;
                2:   O_LUT_2_0_data = 12'd404;
                3:   O_LUT_2_0_data = 12'd478;
                4:   O_LUT_2_0_data = 12'd543;
                5:   O_LUT_2_0_data = 12'd600;
                6:   O_LUT_2_0_data = 12'd652;
                7:   O_LUT_2_0_data = 12'd701;
                8:   O_LUT_2_0_data = 12'd746;
                9:   O_LUT_2_0_data = 12'd789;
                10:  O_LUT_2_0_data = 12'd829;
                11:  O_LUT_2_0_data = 12'd868;
                12:  O_LUT_2_0_data = 12'd905;
                13:  O_LUT_2_0_data = 12'd940;
                14:  O_LUT_2_0_data = 12'd974;
                15:  O_LUT_2_0_data = 12'd1007;
                16:  O_LUT_2_0_data = 12'd1039;
                17:  O_LUT_2_0_data = 12'd1070;
                18:  O_LUT_2_0_data = 12'd1101;
                19:  O_LUT_2_0_data = 12'd1130;
                20:  O_LUT_2_0_data = 12'd1159;
                21:  O_LUT_2_0_data = 12'd1187;
                22:  O_LUT_2_0_data = 12'd1214;
                23:  O_LUT_2_0_data = 12'd1241;
                24:  O_LUT_2_0_data = 12'd1267;
                25:  O_LUT_2_0_data = 12'd1292;
                26:  O_LUT_2_0_data = 12'd1317;
                27:  O_LUT_2_0_data = 12'd1342;
                28:  O_LUT_2_0_data = 12'd1366;
                29:  O_LUT_2_0_data = 12'd1390;
                30:  O_LUT_2_0_data = 12'd1413;
                31:  O_LUT_2_0_data = 12'd1436;
                32:  O_LUT_2_0_data = 12'd1459;
                33:  O_LUT_2_0_data = 12'd1481;
                34:  O_LUT_2_0_data = 12'd1503;
                35:  O_LUT_2_0_data = 12'd1525;
                36:  O_LUT_2_0_data = 12'd1546;
                37:  O_LUT_2_0_data = 12'd1567;
                38:  O_LUT_2_0_data = 12'd1588;
                39:  O_LUT_2_0_data = 12'd1608;
                40:  O_LUT_2_0_data = 12'd1629;
                41:  O_LUT_2_0_data = 12'd1649;
                42:  O_LUT_2_0_data = 12'd1668;
                43:  O_LUT_2_0_data = 12'd1688;
                44:  O_LUT_2_0_data = 12'd1707;
                45:  O_LUT_2_0_data = 12'd1726;
                46:  O_LUT_2_0_data = 12'd1745;
                47:  O_LUT_2_0_data = 12'd1764;
                48:  O_LUT_2_0_data = 12'd1782;
                49:  O_LUT_2_0_data = 12'd1801;
                50:  O_LUT_2_0_data = 12'd1819;
                51:  O_LUT_2_0_data = 12'd1837;
                52:  O_LUT_2_0_data = 12'd1854;
                53:  O_LUT_2_0_data = 12'd1872;
                54:  O_LUT_2_0_data = 12'd1889;
                55:  O_LUT_2_0_data = 12'd1907;
                56:  O_LUT_2_0_data = 12'd1924;
                57:  O_LUT_2_0_data = 12'd1941;
                58:  O_LUT_2_0_data = 12'd1958;
                59:  O_LUT_2_0_data = 12'd1974;
                60:  O_LUT_2_0_data = 12'd1991;
                61:  O_LUT_2_0_data = 12'd2007;
                62:  O_LUT_2_0_data = 12'd2023;
                63:  O_LUT_2_0_data = 12'd2039;
                64:  O_LUT_2_0_data = 12'd2055;
                65:  O_LUT_2_0_data = 12'd2071;
                66:  O_LUT_2_0_data = 12'd2087;
                67:  O_LUT_2_0_data = 12'd2103;
                68:  O_LUT_2_0_data = 12'd2118;
                69:  O_LUT_2_0_data = 12'd2134;
                70:  O_LUT_2_0_data = 12'd2149;
                71:  O_LUT_2_0_data = 12'd2164;
                72:  O_LUT_2_0_data = 12'd2179;
                73:  O_LUT_2_0_data = 12'd2194;
                74:  O_LUT_2_0_data = 12'd2209;
                75:  O_LUT_2_0_data = 12'd2224;
                76:  O_LUT_2_0_data = 12'd2239;
                77:  O_LUT_2_0_data = 12'd2253;
                78:  O_LUT_2_0_data = 12'd2268;
                79:  O_LUT_2_0_data = 12'd2282;
                80:  O_LUT_2_0_data = 12'd2296;
                81:  O_LUT_2_0_data = 12'd2311;
                82:  O_LUT_2_0_data = 12'd2325;
                83:  O_LUT_2_0_data = 12'd2339;
                84:  O_LUT_2_0_data = 12'd2353;
                85:  O_LUT_2_0_data = 12'd2367;
                86:  O_LUT_2_0_data = 12'd2380;
                87:  O_LUT_2_0_data = 12'd2394;
                88:  O_LUT_2_0_data = 12'd2408;
                89:  O_LUT_2_0_data = 12'd2421;
                90:  O_LUT_2_0_data = 12'd2435;
                91:  O_LUT_2_0_data = 12'd2448;
                92:  O_LUT_2_0_data = 12'd2462;
                93:  O_LUT_2_0_data = 12'd2475;
                94:  O_LUT_2_0_data = 12'd2488;
                95:  O_LUT_2_0_data = 12'd2501;
                96:  O_LUT_2_0_data = 12'd2514;
                97:  O_LUT_2_0_data = 12'd2527;
                98:  O_LUT_2_0_data = 12'd2540;
                99:  O_LUT_2_0_data = 12'd2553;
                100: O_LUT_2_0_data = 12'd2566;
                101: O_LUT_2_0_data = 12'd2579;
                102: O_LUT_2_0_data = 12'd2591;
                103: O_LUT_2_0_data = 12'd2604;
                104: O_LUT_2_0_data = 12'd2616;
                105: O_LUT_2_0_data = 12'd2629;
                106: O_LUT_2_0_data = 12'd2641;
                107: O_LUT_2_0_data = 12'd2654;
                108: O_LUT_2_0_data = 12'd2666;
                109: O_LUT_2_0_data = 12'd2678;
                110: O_LUT_2_0_data = 12'd2691;
                111: O_LUT_2_0_data = 12'd2703;
                112: O_LUT_2_0_data = 12'd2715;
                113: O_LUT_2_0_data = 12'd2727;
                114: O_LUT_2_0_data = 12'd2739;
                115: O_LUT_2_0_data = 12'd2751;
                116: O_LUT_2_0_data = 12'd2763;
                117: O_LUT_2_0_data = 12'd2774;
                118: O_LUT_2_0_data = 12'd2786;
                119: O_LUT_2_0_data = 12'd2798;
                120: O_LUT_2_0_data = 12'd2810;
                121: O_LUT_2_0_data = 12'd2821;
                122: O_LUT_2_0_data = 12'd2833;
                123: O_LUT_2_0_data = 12'd2844;
                124: O_LUT_2_0_data = 12'd2856;
                125: O_LUT_2_0_data = 12'd2867;
                126: O_LUT_2_0_data = 12'd2879;
                127: O_LUT_2_0_data = 12'd2890;
                128: O_LUT_2_0_data = 12'd2901;
                129: O_LUT_2_0_data = 12'd2913;
                130: O_LUT_2_0_data = 12'd2924;
                131: O_LUT_2_0_data = 12'd2935;
                132: O_LUT_2_0_data = 12'd2946;
                133: O_LUT_2_0_data = 12'd2957;
                134: O_LUT_2_0_data = 12'd2968;
                135: O_LUT_2_0_data = 12'd2979;
                136: O_LUT_2_0_data = 12'd2990;
                137: O_LUT_2_0_data = 12'd3001;
                138: O_LUT_2_0_data = 12'd3012;
                139: O_LUT_2_0_data = 12'd3023;
                140: O_LUT_2_0_data = 12'd3034;
                141: O_LUT_2_0_data = 12'd3045;
                142: O_LUT_2_0_data = 12'd3055;
                143: O_LUT_2_0_data = 12'd3066;
                144: O_LUT_2_0_data = 12'd3077;
                145: O_LUT_2_0_data = 12'd3087;
                146: O_LUT_2_0_data = 12'd3098;
                147: O_LUT_2_0_data = 12'd3109;
                148: O_LUT_2_0_data = 12'd3119;
                149: O_LUT_2_0_data = 12'd3130;
                150: O_LUT_2_0_data = 12'd3140;
                151: O_LUT_2_0_data = 12'd3150;
                152: O_LUT_2_0_data = 12'd3161;
                153: O_LUT_2_0_data = 12'd3171;
                154: O_LUT_2_0_data = 12'd3182;
                155: O_LUT_2_0_data = 12'd3192;
                156: O_LUT_2_0_data = 12'd3202;
                157: O_LUT_2_0_data = 12'd3212;
                158: O_LUT_2_0_data = 12'd3222;
                159: O_LUT_2_0_data = 12'd3233;
                160: O_LUT_2_0_data = 12'd3243;
                161: O_LUT_2_0_data = 12'd3253;
                162: O_LUT_2_0_data = 12'd3263;
                163: O_LUT_2_0_data = 12'd3273;
                164: O_LUT_2_0_data = 12'd3283;
                165: O_LUT_2_0_data = 12'd3293;
                166: O_LUT_2_0_data = 12'd3303;
                167: O_LUT_2_0_data = 12'd3313;
                168: O_LUT_2_0_data = 12'd3323;
                169: O_LUT_2_0_data = 12'd3332;
                170: O_LUT_2_0_data = 12'd3342;
                171: O_LUT_2_0_data = 12'd3352;
                172: O_LUT_2_0_data = 12'd3362;
                173: O_LUT_2_0_data = 12'd3372;
                174: O_LUT_2_0_data = 12'd3381;
                175: O_LUT_2_0_data = 12'd3391;
                176: O_LUT_2_0_data = 12'd3401;
                177: O_LUT_2_0_data = 12'd3410;
                178: O_LUT_2_0_data = 12'd3420;
                179: O_LUT_2_0_data = 12'd3429;
                180: O_LUT_2_0_data = 12'd3439;
                181: O_LUT_2_0_data = 12'd3448;
                182: O_LUT_2_0_data = 12'd3458;
                183: O_LUT_2_0_data = 12'd3467;
                184: O_LUT_2_0_data = 12'd3477;
                185: O_LUT_2_0_data = 12'd3486;
                186: O_LUT_2_0_data = 12'd3496;
                187: O_LUT_2_0_data = 12'd3505;
                188: O_LUT_2_0_data = 12'd3514;
                189: O_LUT_2_0_data = 12'd3524;
                190: O_LUT_2_0_data = 12'd3533;
                191: O_LUT_2_0_data = 12'd3542;
                192: O_LUT_2_0_data = 12'd3551;
                193: O_LUT_2_0_data = 12'd3561;
                194: O_LUT_2_0_data = 12'd3570;
                195: O_LUT_2_0_data = 12'd3579;
                196: O_LUT_2_0_data = 12'd3588;
                197: O_LUT_2_0_data = 12'd3597;
                198: O_LUT_2_0_data = 12'd3606;
                199: O_LUT_2_0_data = 12'd3615;
                200: O_LUT_2_0_data = 12'd3624;
                201: O_LUT_2_0_data = 12'd3633;
                202: O_LUT_2_0_data = 12'd3642;
                203: O_LUT_2_0_data = 12'd3651;
                204: O_LUT_2_0_data = 12'd3660;
                205: O_LUT_2_0_data = 12'd3669;
                206: O_LUT_2_0_data = 12'd3678;
                207: O_LUT_2_0_data = 12'd3687;
                208: O_LUT_2_0_data = 12'd3696;
                209: O_LUT_2_0_data = 12'd3705;
                210: O_LUT_2_0_data = 12'd3714;
                211: O_LUT_2_0_data = 12'd3723;
                212: O_LUT_2_0_data = 12'd3731;
                213: O_LUT_2_0_data = 12'd3740;
                214: O_LUT_2_0_data = 12'd3749;
                215: O_LUT_2_0_data = 12'd3758;
                216: O_LUT_2_0_data = 12'd3766;
                217: O_LUT_2_0_data = 12'd3775;
                218: O_LUT_2_0_data = 12'd3784;
                219: O_LUT_2_0_data = 12'd3792;
                220: O_LUT_2_0_data = 12'd3801;
                221: O_LUT_2_0_data = 12'd3810;
                222: O_LUT_2_0_data = 12'd3818;
                223: O_LUT_2_0_data = 12'd3827;
                224: O_LUT_2_0_data = 12'd3835;
                225: O_LUT_2_0_data = 12'd3844;
                226: O_LUT_2_0_data = 12'd3852;
                227: O_LUT_2_0_data = 12'd3861;
                228: O_LUT_2_0_data = 12'd3869;
                229: O_LUT_2_0_data = 12'd3878;
                230: O_LUT_2_0_data = 12'd3886;
                231: O_LUT_2_0_data = 12'd3895;
                232: O_LUT_2_0_data = 12'd3903;
                233: O_LUT_2_0_data = 12'd3911;
                234: O_LUT_2_0_data = 12'd3920;
                235: O_LUT_2_0_data = 12'd3928;
                236: O_LUT_2_0_data = 12'd3936;
                237: O_LUT_2_0_data = 12'd3945;
                238: O_LUT_2_0_data = 12'd3953;
                239: O_LUT_2_0_data = 12'd3961;
                240: O_LUT_2_0_data = 12'd3970;
                241: O_LUT_2_0_data = 12'd3978;
                242: O_LUT_2_0_data = 12'd3986;
                243: O_LUT_2_0_data = 12'd3994;
                244: O_LUT_2_0_data = 12'd4002;
                245: O_LUT_2_0_data = 12'd4011;
                246: O_LUT_2_0_data = 12'd4019;
                247: O_LUT_2_0_data = 12'd4027;
                248: O_LUT_2_0_data = 12'd4035;
                249: O_LUT_2_0_data = 12'd4043;
                250: O_LUT_2_0_data = 12'd4051;
                251: O_LUT_2_0_data = 12'd4059;
                252: O_LUT_2_0_data = 12'd4067;
                253: O_LUT_2_0_data = 12'd4075;
                254: O_LUT_2_0_data = 12'd4083;
                255: O_LUT_2_0_data = 12'd4091;
            default: O_LUT_2_0_data = 12'd4091;
        endcase
    end

endmodule