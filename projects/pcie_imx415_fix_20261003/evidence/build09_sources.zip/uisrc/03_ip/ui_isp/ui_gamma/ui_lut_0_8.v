/*******************************MILIANKE*******************************
*Company : MiLianKe Electronic Technology Co., Ltd.
*WebSite:https://www.milianke.com
*TechWeb:https://www.uisrc.com
*tmall-shop:https://milianke.tmall.com
*jd-shop:https://milianke.jd.com
*taobao-shop1: https://milianke.taobao.com
*Create Date: 2024/10/23
*Module Name:
*File Name:
*Description: 
*The reference demo provided by Milianke is only used for learning. 
*We cannot ensure that the demo itself is free of bugs, so users 
*should be responsible for the technical problems and consequences
*caused by the use of their own products.
*Copyright: Copyright (c) MiLianKe
*All rights reserved.
*Revision: 1.0
*Signal description
*1) I_ input
*2) O_ output
*3) IO_ input output
*4) S_ system internal signal
*5) _n activ low
*6) _dg debug signal 
*7) _r delay or register
*8) _s state mechine
*********************************************************************/
/*********ui_lut_0_8 ********************************************
@Description :   gamma=0.8
*****************************************************************/
module ui_lut_0_8 (
    input                          I_clk  ,
    input                          I_rst_n,

    input      [7:0]               I_LUT_0_8_data,
    output reg [11:0]              O_LUT_0_8_data  
);

    always @(*)begin 
        case (I_LUT_0_8_data)
                0:   O_LUT_0_8_data = 12'd1; 
                1:   O_LUT_0_8_data = 12'd6;
                2:   O_LUT_0_8_data = 12'd12;
                3:   O_LUT_0_8_data = 12'd19;
                4:   O_LUT_0_8_data = 12'd26;
                5:   O_LUT_0_8_data = 12'd33;
                6:   O_LUT_0_8_data = 12'd41;
                7:   O_LUT_0_8_data = 12'd49;
                8:   O_LUT_0_8_data = 12'd58;
                9:   O_LUT_0_8_data = 12'd66;
                10:  O_LUT_0_8_data = 12'd75;
                11:  O_LUT_0_8_data = 12'd84;
                12:  O_LUT_0_8_data = 12'd94;
                13:  O_LUT_0_8_data = 12'd103;
                14:  O_LUT_0_8_data = 12'd113;
                15:  O_LUT_0_8_data = 12'd123;
                16:  O_LUT_0_8_data = 12'd133;
                17:  O_LUT_0_8_data = 12'd143;
                18:  O_LUT_0_8_data = 12'd153;
                19:  O_LUT_0_8_data = 12'd163;
                20:  O_LUT_0_8_data = 12'd174;
                21:  O_LUT_0_8_data = 12'd185;
                22:  O_LUT_0_8_data = 12'd196;
                23:  O_LUT_0_8_data = 12'd206;
                24:  O_LUT_0_8_data = 12'd218;
                25:  O_LUT_0_8_data = 12'd229;
                26:  O_LUT_0_8_data = 12'd240;
                27:  O_LUT_0_8_data = 12'd251;
                28:  O_LUT_0_8_data = 12'd263;
                29:  O_LUT_0_8_data = 12'd275;
                30:  O_LUT_0_8_data = 12'd286;
                31:  O_LUT_0_8_data = 12'd298;
                32:  O_LUT_0_8_data = 12'd310;
                33:  O_LUT_0_8_data = 12'd322;
                34:  O_LUT_0_8_data = 12'd334;
                35:  O_LUT_0_8_data = 12'd346;
                36:  O_LUT_0_8_data = 12'd358;
                37:  O_LUT_0_8_data = 12'd371;
                38:  O_LUT_0_8_data = 12'd383;
                39:  O_LUT_0_8_data = 12'd396;
                40:  O_LUT_0_8_data = 12'd408;
                41:  O_LUT_0_8_data = 12'd421;
                42:  O_LUT_0_8_data = 12'd434;
                43:  O_LUT_0_8_data = 12'd446;
                44:  O_LUT_0_8_data = 12'd459;
                45:  O_LUT_0_8_data = 12'd472;
                46:  O_LUT_0_8_data = 12'd485;
                47:  O_LUT_0_8_data = 12'd498;
                48:  O_LUT_0_8_data = 12'd511;
                49:  O_LUT_0_8_data = 12'd525;
                50:  O_LUT_0_8_data = 12'd538;
                51:  O_LUT_0_8_data = 12'd551;
                52:  O_LUT_0_8_data = 12'd565;
                53:  O_LUT_0_8_data = 12'd578;
                54:  O_LUT_0_8_data = 12'd592;
                55:  O_LUT_0_8_data = 12'd605;
                56:  O_LUT_0_8_data = 12'd619;
                57:  O_LUT_0_8_data = 12'd633;
                58:  O_LUT_0_8_data = 12'd647;
                59:  O_LUT_0_8_data = 12'd661;
                60:  O_LUT_0_8_data = 12'd674;
                61:  O_LUT_0_8_data = 12'd688;
                62:  O_LUT_0_8_data = 12'd702;
                63:  O_LUT_0_8_data = 12'd717;
                64:  O_LUT_0_8_data = 12'd731;
                65:  O_LUT_0_8_data = 12'd745;
                66:  O_LUT_0_8_data = 12'd759;
                67:  O_LUT_0_8_data = 12'd773;
                68:  O_LUT_0_8_data = 12'd788;
                69:  O_LUT_0_8_data = 12'd802;
                70:  O_LUT_0_8_data = 12'd817;
                71:  O_LUT_0_8_data = 12'd831;
                72:  O_LUT_0_8_data = 12'd846;
                73:  O_LUT_0_8_data = 12'd860;
                74:  O_LUT_0_8_data = 12'd875;
                75:  O_LUT_0_8_data = 12'd890;
                76:  O_LUT_0_8_data = 12'd904;
                77:  O_LUT_0_8_data = 12'd919;
                78:  O_LUT_0_8_data = 12'd934;
                79:  O_LUT_0_8_data = 12'd949;
                80:  O_LUT_0_8_data = 12'd964;
                81:  O_LUT_0_8_data = 12'd979;
                82:  O_LUT_0_8_data = 12'd994;
                83:  O_LUT_0_8_data = 12'd1009;
                84:  O_LUT_0_8_data = 12'd1024;
                85:  O_LUT_0_8_data = 12'd1039;
                86:  O_LUT_0_8_data = 12'd1055;
                87:  O_LUT_0_8_data = 12'd1070;
                88:  O_LUT_0_8_data = 12'd1085;
                89:  O_LUT_0_8_data = 12'd1101;
                90:  O_LUT_0_8_data = 12'd1116;
                91:  O_LUT_0_8_data = 12'd1131;
                92:  O_LUT_0_8_data = 12'd1147;
                93:  O_LUT_0_8_data = 12'd1162;
                94:  O_LUT_0_8_data = 12'd1178;
                95:  O_LUT_0_8_data = 12'd1194;
                96:  O_LUT_0_8_data = 12'd1209;
                97:  O_LUT_0_8_data = 12'd1225;
                98:  O_LUT_0_8_data = 12'd1241;
                99:  O_LUT_0_8_data = 12'd1257;
                100: O_LUT_0_8_data = 12'd1272;
                101: O_LUT_0_8_data = 12'd1288;
                102: O_LUT_0_8_data = 12'd1304;
                103: O_LUT_0_8_data = 12'd1320;
                104: O_LUT_0_8_data = 12'd1336;
                105: O_LUT_0_8_data = 12'd1352;
                106: O_LUT_0_8_data = 12'd1368;
                107: O_LUT_0_8_data = 12'd1384;
                108: O_LUT_0_8_data = 12'd1400;
                109: O_LUT_0_8_data = 12'd1416;
                110: O_LUT_0_8_data = 12'd1433;
                111: O_LUT_0_8_data = 12'd1449;
                112: O_LUT_0_8_data = 12'd1465;
                113: O_LUT_0_8_data = 12'd1481;
                114: O_LUT_0_8_data = 12'd1498;
                115: O_LUT_0_8_data = 12'd1514;
                116: O_LUT_0_8_data = 12'd1530;
                117: O_LUT_0_8_data = 12'd1547;
                118: O_LUT_0_8_data = 12'd1563;
                119: O_LUT_0_8_data = 12'd1580;
                120: O_LUT_0_8_data = 12'd1596;
                121: O_LUT_0_8_data = 12'd1613;
                122: O_LUT_0_8_data = 12'd1630;
                123: O_LUT_0_8_data = 12'd1646;
                124: O_LUT_0_8_data = 12'd1663;
                125: O_LUT_0_8_data = 12'd1680;
                126: O_LUT_0_8_data = 12'd1696;
                127: O_LUT_0_8_data = 12'd1713;
                128: O_LUT_0_8_data = 12'd1730;
                129: O_LUT_0_8_data = 12'd1747;
                130: O_LUT_0_8_data = 12'd1764;
                131: O_LUT_0_8_data = 12'd1781;
                132: O_LUT_0_8_data = 12'd1798;
                133: O_LUT_0_8_data = 12'd1815;
                134: O_LUT_0_8_data = 12'd1832;
                135: O_LUT_0_8_data = 12'd1849;
                136: O_LUT_0_8_data = 12'd1866;
                137: O_LUT_0_8_data = 12'd1883;
                138: O_LUT_0_8_data = 12'd1900;
                139: O_LUT_0_8_data = 12'd1917;
                140: O_LUT_0_8_data = 12'd1934;
                141: O_LUT_0_8_data = 12'd1952;
                142: O_LUT_0_8_data = 12'd1969;
                143: O_LUT_0_8_data = 12'd1986;
                144: O_LUT_0_8_data = 12'd2003;
                145: O_LUT_0_8_data = 12'd2021;
                146: O_LUT_0_8_data = 12'd2038;
                147: O_LUT_0_8_data = 12'd2056;
                148: O_LUT_0_8_data = 12'd2073;
                149: O_LUT_0_8_data = 12'd2091;
                150: O_LUT_0_8_data = 12'd2108;
                151: O_LUT_0_8_data = 12'd2126;
                152: O_LUT_0_8_data = 12'd2143;
                153: O_LUT_0_8_data = 12'd2161;
                154: O_LUT_0_8_data = 12'd2178;
                155: O_LUT_0_8_data = 12'd2196;
                156: O_LUT_0_8_data = 12'd2214;
                157: O_LUT_0_8_data = 12'd2231;
                158: O_LUT_0_8_data = 12'd2249;
                159: O_LUT_0_8_data = 12'd2267;
                160: O_LUT_0_8_data = 12'd2285;
                161: O_LUT_0_8_data = 12'd2302;
                162: O_LUT_0_8_data = 12'd2320;
                163: O_LUT_0_8_data = 12'd2338;
                164: O_LUT_0_8_data = 12'd2356;
                165: O_LUT_0_8_data = 12'd2374;
                166: O_LUT_0_8_data = 12'd2392;
                167: O_LUT_0_8_data = 12'd2410;
                168: O_LUT_0_8_data = 12'd2428;
                169: O_LUT_0_8_data = 12'd2446;
                170: O_LUT_0_8_data = 12'd2464;
                171: O_LUT_0_8_data = 12'd2482;
                172: O_LUT_0_8_data = 12'd2500;
                173: O_LUT_0_8_data = 12'd2518;
                174: O_LUT_0_8_data = 12'd2536;
                175: O_LUT_0_8_data = 12'd2555;
                176: O_LUT_0_8_data = 12'd2573;
                177: O_LUT_0_8_data = 12'd2591;
                178: O_LUT_0_8_data = 12'd2609;
                179: O_LUT_0_8_data = 12'd2628;
                180: O_LUT_0_8_data = 12'd2646;
                181: O_LUT_0_8_data = 12'd2664;
                182: O_LUT_0_8_data = 12'd2683;
                183: O_LUT_0_8_data = 12'd2701;
                184: O_LUT_0_8_data = 12'd2719;
                185: O_LUT_0_8_data = 12'd2738;
                186: O_LUT_0_8_data = 12'd2756;
                187: O_LUT_0_8_data = 12'd2775;
                188: O_LUT_0_8_data = 12'd2793;
                189: O_LUT_0_8_data = 12'd2812;
                190: O_LUT_0_8_data = 12'd2830;
                191: O_LUT_0_8_data = 12'd2849;
                192: O_LUT_0_8_data = 12'd2868;
                193: O_LUT_0_8_data = 12'd2886;
                194: O_LUT_0_8_data = 12'd2905;
                195: O_LUT_0_8_data = 12'd2924;
                196: O_LUT_0_8_data = 12'd2942;
                197: O_LUT_0_8_data = 12'd2961;
                198: O_LUT_0_8_data = 12'd2980;
                199: O_LUT_0_8_data = 12'd2999;
                200: O_LUT_0_8_data = 12'd3017;
                201: O_LUT_0_8_data = 12'd3036;
                202: O_LUT_0_8_data = 12'd3055;
                203: O_LUT_0_8_data = 12'd3074;
                204: O_LUT_0_8_data = 12'd3093;
                205: O_LUT_0_8_data = 12'd3112;
                206: O_LUT_0_8_data = 12'd3131;
                207: O_LUT_0_8_data = 12'd3150;
                208: O_LUT_0_8_data = 12'd3169;
                209: O_LUT_0_8_data = 12'd3188;
                210: O_LUT_0_8_data = 12'd3207;
                211: O_LUT_0_8_data = 12'd3226;
                212: O_LUT_0_8_data = 12'd3245;
                213: O_LUT_0_8_data = 12'd3264;
                214: O_LUT_0_8_data = 12'd3283;
                215: O_LUT_0_8_data = 12'd3302;
                216: O_LUT_0_8_data = 12'd3321;
                217: O_LUT_0_8_data = 12'd3341;
                218: O_LUT_0_8_data = 12'd3360;
                219: O_LUT_0_8_data = 12'd3379;
                220: O_LUT_0_8_data = 12'd3398;
                221: O_LUT_0_8_data = 12'd3418;
                222: O_LUT_0_8_data = 12'd3437;
                223: O_LUT_0_8_data = 12'd3456;
                224: O_LUT_0_8_data = 12'd3476;
                225: O_LUT_0_8_data = 12'd3495;
                226: O_LUT_0_8_data = 12'd3514;
                227: O_LUT_0_8_data = 12'd3534;
                228: O_LUT_0_8_data = 12'd3553;
                229: O_LUT_0_8_data = 12'd3573;
                230: O_LUT_0_8_data = 12'd3592;
                231: O_LUT_0_8_data = 12'd3612;
                232: O_LUT_0_8_data = 12'd3631;
                233: O_LUT_0_8_data = 12'd3651;
                234: O_LUT_0_8_data = 12'd3670;
                235: O_LUT_0_8_data = 12'd3690;
                236: O_LUT_0_8_data = 12'd3709;
                237: O_LUT_0_8_data = 12'd3729;
                238: O_LUT_0_8_data = 12'd3749;
                239: O_LUT_0_8_data = 12'd3768;
                240: O_LUT_0_8_data = 12'd3788;
                241: O_LUT_0_8_data = 12'd3808;
                242: O_LUT_0_8_data = 12'd3827;
                243: O_LUT_0_8_data = 12'd3847;
                244: O_LUT_0_8_data = 12'd3867;
                245: O_LUT_0_8_data = 12'd3887;
                246: O_LUT_0_8_data = 12'd3906;
                247: O_LUT_0_8_data = 12'd3926;
                248: O_LUT_0_8_data = 12'd3946;
                249: O_LUT_0_8_data = 12'd3966;
                250: O_LUT_0_8_data = 12'd3986;
                251: O_LUT_0_8_data = 12'd4006;
                252: O_LUT_0_8_data = 12'd4026;
                253: O_LUT_0_8_data = 12'd4046;
                254: O_LUT_0_8_data = 12'd4066;
                255: O_LUT_0_8_data = 12'd4086;
            default: O_LUT_0_8_data = 12'd4089;
        endcase
    end
    
endmodule